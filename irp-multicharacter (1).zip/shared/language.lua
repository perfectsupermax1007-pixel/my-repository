local Lang = Config.Language

function _U(key)
    return Lang[key] or key
end
