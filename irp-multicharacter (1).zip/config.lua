Config = {}

Config.MaxCharacters = 3 -- Default max slots per player
Config.DefaultSpawn = vector4(185.28, -933.95, 30.68, 90.0) -- Default spawn after character creation

Config.Webhooks = {
    ['character_created'] = '',
    ['character_deleted'] = '',
    ['character_selected'] = '',
    ['error'] = '',
    ['suspicious'] = ''
}

-- Discord webhook colors (decimal)
Config.WebhookColors = {
    success = 3066993,   -- Green
    error = 15158332,    -- Red
    warning = 16705372   -- Yellow
}

-- Character creation settings
Config.CharacterCreation = {
    MinNameLength = 2,
    MaxNameLength = 32,
    MinDOBAge = 18, -- Minimum age in years
    AllowedGenders = { 'male', 'female' }
}

-- Appearance settings (illenium-appearance)
Config.Appearance = {
    Ped = true,       -- Use ped model
    UseTarget = false -- Not needed, we use direct call
}

-- Language strings
Config.Language = {
    ["no_characters"] = "No characters found. Create your first character!",
    ["select_character"] = "Select Your Character",
    ["create_character"] = "Create Character",
    ["delete_character"] = "Delete Character",
    ["confirm_delete"] = "Are you sure you want to delete this character? This cannot be undone!",
    ["char_name"] = "Name",
    ["char_dob"] = "Date of Birth",
    ["char_gender"] = "Gender",
    ["male"] = "Male",
    ["female"] = "Female",
    ["continue"] = "Continue",
    ["back"] = "Back",
    ["loading"] = "Loading...",
    ["appearance"] = "Customize Appearance",
    ["finish"] = "Finish",
    ["invalid_name"] = "Invalid name",
    ["invalid_dob"] = "Invalid date of birth",
    ["invalid_gender"] = "Invalid gender",
    ["invalid_data"] = "Invalid data received.",
    ["character_created"] = "Character created successfully!",
    ["character_selected"] = "Character selected.",
    ["character_deleted"] = "Character deleted.",
    ["max_slots"] = "You have reached maximum character slots.",
    ["error_occurred"] = "An error occurred. Please try again.",
    ["player_not_found"] = "Player not found.",
    ["character_not_found"] = "Character not found.",
    ["rate_limit"] = "Please wait before trying again.",
    ["cannot_delete_last"] = "You cannot delete your last character.",
    ["database_error"] = "A database error occurred. Please try again.",
    ["no_permission"] = "No permission.",
    ["invalid_arguments"] = "Invalid arguments."
}
