local QBCore = exports['qb-core']:GetCoreObject()
local PlayerData = {}
local isChoosingCharacter = false
local currentCharacters = {}

-- Events from QB Core
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
    TriggerServerEvent('irp-multicharacter:server:playerLoaded')
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
    PlayerData.job = job
end)

-- Open character selection UI
RegisterNetEvent('irp-multicharacter:client:openSelection', function(characters)
    currentCharacters = characters
    isChoosingCharacter = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'showSelection',
        characters = characters,
        maxSlots = Config.MaxCharacters,
        lang = Config.Language
    })
end)

-- Open character creation UI
RegisterNetEvent('irp-multicharacter:client:openCreation', function()
    isChoosingCharacter = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'showCreation',
        lang = Config.Language
    })
end)

-- Close UI
RegisterNetEvent('irp-multicharacter:client:closeUI', function()
    isChoosingCharacter = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end)

-- Handle NUI callbacks
RegisterNUICallback('selectCharacter', function(data, cb)
    local characterId = tonumber(data.id)
    if not characterId then
        TriggerServerEvent('irp-multicharacter:server:logSuspicious', 'Invalid character ID in selectCharacter')
        cb('error')
        return
    end
    TriggerServerEvent('irp-multicharacter:server:selectCharacter', characterId)
    cb('ok')
end)

RegisterNUICallback('deleteCharacter', function(data, cb)
    local characterId = tonumber(data.id)
    if not characterId then
        TriggerServerEvent('irp-multicharacter:server:logSuspicious', 'Invalid character ID in deleteCharacter')
        cb('error')
        return
    end
    TriggerServerEvent('irp-multicharacter:server:deleteCharacter', characterId)
    cb('ok')
end)

RegisterNUICallback('createCharacter', function(data, cb)
    local name = tostring(data.name or '')
    local dob = tostring(data.dob or '')
    local gender = tostring(data.gender or '')

    -- Basic client-side validation
    if #name < Config.CharacterCreation.MinNameLength or #name > Config.CharacterCreation.MaxNameLength then
        TriggerServerEvent('irp-multicharacter:server:logSuspicious', 'Invalid name in createCharacter')
        cb('error')
        return
    end

    if #dob ~= 10 then -- expect YYYY-MM-DD
        TriggerServerEvent('irp-multicharacter:server:logSuspicious', 'Invalid dob in createCharacter')
        cb('error')
        return
    end

    local genderValid = false
    for _, g in ipairs(Config.CharacterCreation.AllowedGenders) do
        if gender == g then
            genderValid = true
            break
        end
    end
    if not genderValid then
        TriggerServerEvent('irp-multicharacter:server:logSuspicious', 'Invalid gender in createCharacter')
        cb('error')
        return
    end

    -- Open appearance menu
    TriggerEvent('irp-multicharacter:client:openAppearance', {
        name = name,
        dob = dob,
        gender = gender
    })
    cb('ok')
end)

RegisterNUICallback('close', function(_, cb)
    if isChoosingCharacter then
        SetNuiFocus(false, false)
        isChoosingCharacter = false
    end
    cb('ok')
end)

-- Appearance handling
RegisterNetEvent('irp-multicharacter:client:openAppearance', function(characterData)
    local ped = PlayerPedId()

    -- illenium-appearance startPlayerCustomization is asynchronous (callback-based)
    local ok = pcall(function()
        exports['illenium-appearance']:startPlayerCustomization(ped, function(appearanceData)
            if appearanceData then
                TriggerServerEvent('irp-multicharacter:server:createCharacter', {
                    name = characterData.name,
                    dob = characterData.dob,
                    gender = characterData.gender,
                    appearance = json.encode(appearanceData)
                })
            else
                -- User cancelled customization or no data returned
                TriggerServerEvent('irp-multicharacter:server:logSuspicious', 'Appearance customization returned no data')
                TriggerEvent('irp-multicharacter:client:openCreation')
            end
        end)
    end)

    if not ok then
        -- Fallback: startPlayerCustomization unavailable, create with default appearance
        TriggerServerEvent('irp-multicharacter:server:createCharacter', {
            name = characterData.name,
            dob = characterData.dob,
            gender = characterData.gender,
            appearance = nil
        })
    end
end)

-- After character is created/selected, apply appearance and spawn
RegisterNetEvent('irp-multicharacter:client:applyAppearance', function(appearanceData)
    -- Freeze ped at spawn while applying appearance
    local ped = PlayerPedId()
    SetEntityCoords(ped, Config.DefaultSpawn.x, Config.DefaultSpawn.y, Config.DefaultSpawn.z, false, false, false, false)
    SetEntityHeading(ped, Config.DefaultSpawn.w)

    if appearanceData then
        local decoded = json.decode(appearanceData)
        if decoded then
            local ok, err = pcall(function()
                -- Set the correct ped model first (handles gender changes)
                exports['illenium-appearance']:setPlayerModel(decoded.model or decoded.hash or decoded)
                exports['illenium-appearance']:setPlayerAppearance(decoded)
            end)
            if not ok then
                TriggerServerEvent('irp-multicharacter:server:logError', 'Failed to apply appearance: ' .. tostring(err))
            end
        end
    end

    -- Finalize spawn
    FreezeEntityPosition(ped, false)
    DoScreenFadeIn(1000)
    isChoosingCharacter = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end)

-- Soft-freeze player while choosing character (does not steal all controls)
CreateThread(function()
    while true do
        if isChoosingCharacter then
            FreezeEntityPosition(PlayerPedId(), true)
            Wait(0)
        else
            Wait(1000)
        end
    end
end)

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    isChoosingCharacter = false
end)
