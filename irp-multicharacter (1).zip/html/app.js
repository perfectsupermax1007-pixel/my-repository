let currentCharacters = [];

window.addEventListener('message', function(event) {
    const data = event.data;
    switch (data.action) {
        case 'showSelection':
            showSelection(data.characters, data.lang);
            break;
        case 'showCreation':
            showCreation(data.lang);
            break;
        case 'close':
            closeAll();
            break;
    }
});

function showSelection(characters, lang) {
    currentCharacters = characters;
    document.getElementById('selection').classList.remove('hidden');
    document.getElementById('creation').classList.add('hidden');
    document.getElementById('selTitle').innerText = lang.select_character || 'Select Your Character';
    document.getElementById('createBtn').innerText = lang.create_character || 'Create Character';
    const list = document.getElementById('charList');
    list.innerHTML = '';
    characters.forEach(char => {
        const card = document.createElement('div');
        card.className = 'character-card';
        card.innerHTML = `
            <div class="character-info">
                <div class="character-name">${char.name}</div>
                <div class="character-details">DOB: ${char.dob} | Gender: ${char.gender}</div>
            </div>
            <button class="delete-btn" data-id="${char.id}">${lang.delete_character || 'Delete'}</button>
        `;
        card.addEventListener('click', function(e) {
            if (e.target.classList.contains('delete-btn')) return;
            selectCharacter(char.id);
        });
        card.querySelector('.delete-btn').addEventListener('click', function(e) {
            e.stopPropagation();
            if (confirm(lang.confirm_delete || 'Are you sure?')) {
                deleteCharacter(char.id);
            }
        });
        list.appendChild(card);
    });
}

function showCreation(lang) {
    document.getElementById('selection').classList.add('hidden');
    document.getElementById('creation').classList.remove('hidden');
    document.getElementById('creTitle').innerText = lang.create_character || 'Create Character';
    document.getElementById('name').placeholder = lang.char_name || 'Name';
    document.getElementById('dob').placeholder = lang.char_dob || 'Date of Birth';
    document.getElementById('appearanceBtn').innerText = lang.appearance || 'Customize Appearance';
    document.getElementById('backBtn').innerText = lang.back || 'Back';
    document.getElementById('createForm').onsubmit = function(e) {
        e.preventDefault();
        const name = document.getElementById('name').value.trim();
        const dob = document.getElementById('dob').value;
        const gender = document.getElementById('gender').value;
        if (!name || !dob || !gender) return;
        fetch(`https://${GetParentResourceName()}/createCharacter`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, dob, gender })
        });
    };
    document.getElementById('backBtn').onclick = function() {
        closeAll();
    };
}

function closeAll() {
    document.getElementById('selection').classList.add('hidden');
    document.getElementById('creation').classList.add('hidden');
}

function selectCharacter(id) {
    fetch(`https://${GetParentResourceName()}/selectCharacter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    });
}

function deleteCharacter(id) {
    fetch(`https://${GetParentResourceName()}/deleteCharacter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    });
}
