CREATE TABLE IF NOT EXISTS `player_characters` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `license` VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL UNIQUE,
    `charinfo` LONGTEXT NOT NULL,
    `metadata` LONGTEXT NOT NULL,
    `appearance` LONGTEXT DEFAULT NULL,
    `job` VARCHAR(50) DEFAULT 'unemployed',
    `job_grade` INT DEFAULT 0,
    `gang` VARCHAR(50) DEFAULT 'none',
    `gang_grade` INT DEFAULT 0,
    `money` LONGTEXT DEFAULT NULL,
    `position` LONGTEXT DEFAULT NULL,
    `is_active` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (`license`),
    INDEX (`citizenid`),
    INDEX (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add license column to players table if not exists (needed for linking)
ALTER TABLE `players` ADD COLUMN `license` VARCHAR(50) DEFAULT NULL AFTER `citizenid`;

CREATE TABLE IF NOT EXISTS `player_extra_slots` (
    `license` VARCHAR(50) PRIMARY KEY,
    `extra_slots` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
