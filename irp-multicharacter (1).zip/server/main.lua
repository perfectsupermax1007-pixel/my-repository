local QBCore = exports['qb-core']:GetCoreObject()
local cooldowns = {}
local selectingCharacter = {} -- guard against re-opening UI during selection

-- Utility functions (defined first so they can be used anywhere)
local function sendWebhook(webhookType, message, fields)
    local url = Config.Webhooks[webhookType]
    if not url or url == '' then return end

    -- Map webhook type to a color (success / error / warning)
    local color = Config.WebhookColors.warning
    if webhookType == 'error' or webhookType == 'suspicious' then
        color = Config.WebhookColors.error
    elseif webhookType == 'character_created' or webhookType == 'character_deleted' or webhookType == 'character_selected' then
        color = Config.WebhookColors.success
    end

    local embed = {
        {
            ['title'] = 'irp-multicharacter',
            ['description'] = message,
            ['color'] = color,
            ['timestamp'] = os.date('!%Y-%m-%dT%H:%M:%SZ')
        }
    }
    if fields then
        embed[1]['fields'] = fields
    end
    PerformHttpRequest(url, function(err, text, headers) end, 'POST', json.encode({ embeds = embed }), { ['Content-Type'] = 'application/json' })
end

local function logError(message)
    print('[^1ERROR^7] irp-multicharacter: ' .. message)
    sendWebhook('error', message)
end

local function logSuspicious(message)
    print('[^3SUSPICIOUS^7] irp-multicharacter: ' .. message)
    sendWebhook('suspicious', message)
end

-- Initialize database schema if not exists
CreateThread(function()
    local success = MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `player_characters` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `license` VARCHAR(50) NOT NULL,
            `citizenid` VARCHAR(50) NOT NULL UNIQUE,
            `charinfo` LONGTEXT NOT NULL,
            `metadata` LONGTEXT NOT NULL,
            `appearance` LONGTEXT DEFAULT NULL,
            `job` VARCHAR(50) DEFAULT 'unemployed',
            `job_grade` INT DEFAULT 0,
            `gang` VARCHAR(50) DEFAULT 'none',
            `gang_grade` INT DEFAULT 0,
            `money` LONGTEXT DEFAULT NULL,
            `position` LONGTEXT DEFAULT NULL,
            `is_active` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (`license`),
            INDEX (`citizenid`),
            INDEX (`is_active`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])
    if not success then
        logError('Failed to create player_characters table')
        return
    end

    -- Add license column to players table if missing
    local columnCheck = MySQL.query.await([[
        SELECT COUNT(*) as count FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'players' AND COLUMN_NAME = 'license'
    ]])
    if columnCheck[1] and columnCheck[1].count == 0 then
        local alter = MySQL.query.await([[ALTER TABLE `players` ADD COLUMN `license` VARCHAR(50) DEFAULT NULL AFTER `citizenid`]])
        if not alter then
            logError('Failed to add license column to players table')
        end
    end

    -- Create player_extra_slots table
    local slotsTable = MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `player_extra_slots` (
            `license` VARCHAR(50) PRIMARY KEY,
            `extra_slots` INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])
    if not slotsTable then
        logError('Failed to create player_extra_slots table')
    end
end)

RegisterNetEvent('irp-multicharacter:server:sendWebhook', function(webhookType, message)
    sendWebhook(webhookType, message)
end)

-- Logging events fired from the client (source is not used, but kept for context)
RegisterNetEvent('irp-multicharacter:server:logSuspicious', function(message)
    logSuspicious(message or 'No message')
end)

RegisterNetEvent('irp-multicharacter:server:logError', function(message)
    logError(message or 'No message')
end)

-- Get player's max character slots
local function getMaxSlots(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return Config.MaxCharacters end
    local license = Player.PlayerData.license
    local result = MySQL.single.await('SELECT extra_slots FROM player_extra_slots WHERE license = ?', { license })
    local extra = result and result.extra_slots or 0
    return Config.MaxCharacters + extra
end

-- Check character count
local function getCharacterCount(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return 0 end
    local license = Player.PlayerData.license
    local result = MySQL.query.await('SELECT COUNT(*) as count FROM player_characters WHERE license = ?', { license })
    return result[1] and result[1].count or 0
end

-- Check if player has any characters
local function hasCharacters(src)
    return getCharacterCount(src) > 0
end

-- Build the character list sent to the client
local function getCharacterList(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return {} end
    local license = Player.PlayerData.license
    local characters = MySQL.query.await('SELECT id, citizenid, charinfo, appearance FROM player_characters WHERE license = ? ORDER BY is_active DESC, id ASC', { license })
    local charList = {}
    for _, char in ipairs(characters) do
        local charinfo = json.decode(char.charinfo)
        charList[#charList+1] = {
            id = char.id,
            citizenid = char.citizenid,
            name = (charinfo.firstname or '') .. ' ' .. (charinfo.lastname or ''),
            dob = charinfo.birthdate,
            gender = charinfo.gender,
            appearance = char.appearance
        }
    end
    return charList
end

-- Generate unique citizenid (IRP + 8 uppercase alphanumeric chars)
local function generateCitizenId()
    local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    local id = ''
    for i = 1, 8 do
        local rand = math.random(1, #chars)
        id = id .. chars:sub(rand, rand)
    end
    return 'IRP' .. id
end

-- Create new character
local function createCharacter(src, data)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false, 'player_not_found' end

    -- Rate limit
    if cooldowns[src] and os.time() - cooldowns[src] < 10 then
        return false, 'rate_limit'
    end
    cooldowns[src] = os.time()

    -- Validate args
    if type(data) ~= 'table' then return false, 'invalid_data' end
    if type(data.name) ~= 'string' or #data.name < 2 or #data.name > 32 then return false, 'invalid_name' end
    if type(data.dob) ~= 'string' or #data.dob ~= 10 then return false, 'invalid_dob' end
    local genderValid = false
    for _, g in ipairs(Config.CharacterCreation.AllowedGenders) do
        if data.gender == g then genderValid = true break end
    end
    if not genderValid then return false, 'invalid_gender' end

    local license = Player.PlayerData.license
    local maxSlots = getMaxSlots(src)
    local currentCount = getCharacterCount(src)
    if currentCount >= maxSlots then
        return false, 'max_slots'
    end

    -- Generate unique citizenid (also check players table)
    local citizenid = generateCitizenId()
    local existing = MySQL.single.await('SELECT citizenid FROM player_characters WHERE citizenid = ?', { citizenid })
        or MySQL.single.await('SELECT citizenid FROM players WHERE citizenid = ?', { citizenid })
    while existing do
        citizenid = generateCitizenId()
        existing = MySQL.single.await('SELECT citizenid FROM player_characters WHERE citizenid = ?', { citizenid })
            or MySQL.single.await('SELECT citizenid FROM players WHERE citizenid = ?', { citizenid })
    end

    -- Default charinfo and metadata
    local charinfo = {
        firstname = data.name,
        lastname = '',
        birthdate = data.dob,
        gender = data.gender,
        nationality = 'American',
        phone = '',
        account = '',
        info = ''
    }
    local metadata = {}
    local appearance = data.appearance or nil

    -- Insert into player_characters
    local insertChar = MySQL.insert.await('INSERT INTO player_characters (license, citizenid, charinfo, metadata, appearance, job, job_grade, gang, gang_grade, money, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', {
        license,
        citizenid,
        json.encode(charinfo),
        json.encode(metadata),
        appearance,
        'unemployed',
        0,
        'none',
        0,
        json.encode({ cash = 500, bank = 5000, crypto = 0 }),
        json.encode({ x = Config.DefaultSpawn.x, y = Config.DefaultSpawn.y, z = Config.DefaultSpawn.z, heading = Config.DefaultSpawn.w })
    })
    if not insertChar then
        logError('Failed to insert character into player_characters')
        return false, 'database_error'
    end

    -- Insert into players table for QB core
    local insertPlayer = MySQL.insert.await('INSERT INTO players (citizenid, license, charinfo, metadata, money, job, job_grade, gang, gang_grade, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', {
        citizenid,
        license,
        json.encode(charinfo),
        json.encode(metadata),
        json.encode({ cash = 500, bank = 5000, crypto = 0 }),
        'unemployed',
        0,
        'none',
        0,
        json.encode({ x = Config.DefaultSpawn.x, y = Config.DefaultSpawn.y, z = Config.DefaultSpawn.z, heading = Config.DefaultSpawn.w })
    })
    if not insertPlayer then
        -- Clean up on failure
        MySQL.query.await('DELETE FROM player_characters WHERE citizenid = ?', { citizenid })
        logError('Failed to insert into players table')
        return false, 'database_error'
    end

    -- Set as active character
    MySQL.update.await('UPDATE player_characters SET is_active = 0 WHERE license = ?', { license })
    MySQL.update.await('UPDATE player_characters SET is_active = 1 WHERE citizenid = ?', { citizenid })

    -- Send webhook
    sendWebhook('character_created', 'Character created', {
        { name = 'Player', value = GetPlayerName(src) .. ' (' .. license .. ')' },
        { name = 'Character', value = data.name },
        { name = 'CitizenID', value = citizenid }
    })

    return true, citizenid
end

-- Delete character
local function deleteCharacter(src, characterId)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false, 'player_not_found' end

    if cooldowns[src] and os.time() - cooldowns[src] < 10 then
        return false, 'rate_limit'
    end
    cooldowns[src] = os.time()

    local license = Player.PlayerData.license
    local character = MySQL.single.await('SELECT * FROM player_characters WHERE id = ? AND license = ?', { characterId, license })
    if not character then
        logSuspicious('Attempt to delete non-owned character by ' .. GetPlayerName(src) .. ' (ID: ' .. tostring(characterId) .. ')')
        return false, 'character_not_found'
    end

    -- Prevent deleting if it's the only character
    local count = getCharacterCount(src)
    if count <= 1 then
        return false, 'cannot_delete_last'
    end

    -- Delete from both tables
    MySQL.query.await('DELETE FROM player_characters WHERE id = ?', { characterId })
    MySQL.query.await('DELETE FROM players WHERE citizenid = ?', { character.citizenid })

    -- If deleted active, set another as active
    if character.is_active == 1 then
        local nextChar = MySQL.single.await('SELECT citizenid FROM player_characters WHERE license = ? ORDER BY id LIMIT 1', { license })
        if nextChar then
            MySQL.update.await('UPDATE player_characters SET is_active = 0 WHERE license = ?', { license })
            MySQL.update.await('UPDATE player_characters SET is_active = 1 WHERE citizenid = ?', { nextChar.citizenid })
        end
    end

    sendWebhook('character_deleted', 'Character deleted', {
        { name = 'Player', value = GetPlayerName(src) .. ' (' .. license .. ')' },
        { name = 'Character ID', value = tostring(characterId) }
    })
    return true, 'character_deleted'
end

-- Select character
local function selectCharacter(src, characterId)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false, 'player_not_found' end

    if cooldowns[src] and os.time() - cooldowns[src] < 10 then
        return false, 'rate_limit'
    end
    cooldowns[src] = os.time()

    local license = Player.PlayerData.license
    local character = MySQL.single.await('SELECT * FROM player_characters WHERE id = ? AND license = ?', { characterId, license })
    if not character then
        logSuspicious('Attempt to select non-owned character by ' .. GetPlayerName(src) .. ' (ID: ' .. tostring(characterId) .. ')')
        return false, 'character_not_found'
    end

    -- Update active flags
    MySQL.update.await('UPDATE player_characters SET is_active = 0 WHERE license = ?', { license })
    MySQL.update.await('UPDATE player_characters SET is_active = 1 WHERE citizenid = ?', { character.citizenid })

    -- Set guard so the re-fired playerLoaded event does not reopen the UI
    selectingCharacter[src] = true

    -- Load the character into QBCore and trigger reload events
    local loaded = QBCore.Player.LoadCharacter(Player, character.citizenid)
    if not loaded then
        selectingCharacter[src] = nil
        logError('Failed to load character for player ' .. GetPlayerName(src) .. ' (citizenid: ' .. character.citizenid .. ')')
        return false, 'error_occurred'
    end

    selectingCharacter[src] = nil

    TriggerClientEvent('irp-multicharacter:client:applyAppearance', src, character.appearance)

    sendWebhook('character_selected', 'Character selected', {
        { name = 'Player', value = GetPlayerName(src) .. ' (' .. license .. ')' },
        { name = 'Character', value = character.citizenid }
    })
    return true, 'character_selected'
end

-- Player loaded event
RegisterNetEvent('irp-multicharacter:server:playerLoaded', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    -- If we are mid-selection (just switched characters), do not reopen the UI
    if selectingCharacter[src] then return end

    -- Check if player has characters
    local count = getCharacterCount(src)
    if count == 0 then
        -- No characters, force creation
        TriggerClientEvent('irp-multicharacter:client:openCreation', src)
    else
        -- Get character list
        TriggerClientEvent('irp-multicharacter:client:openSelection', src, getCharacterList(src))
    end
end)

-- Events from client
RegisterNetEvent('irp-multicharacter:server:createCharacter', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local success, citizenid = createCharacter(src, data)
    if success then
        -- Fetch the new character's id and load it in one go
        local newChar = MySQL.single.await('SELECT id FROM player_characters WHERE citizenid = ?', { citizenid })
        if newChar then
            selectCharacter(src, newChar.id)
        else
            logError('Failed to find newly created character by citizenid: ' .. tostring(citizenid))
            TriggerClientEvent('QBCore:Notify', src, _U('error_occurred'), 'error')
        end
    else
        TriggerClientEvent('QBCore:Notify', src, _U(citizenid) or _U('error_occurred'), 'error')
    end
end)

RegisterNetEvent('irp-multicharacter:server:selectCharacter', function(characterId)
    local src = source
    local success, message = selectCharacter(src, characterId)
    if not success then
        TriggerClientEvent('QBCore:Notify', src, _U(message), 'error')
    end
end)

RegisterNetEvent('irp-multicharacter:server:deleteCharacter', function(characterId)
    local src = source
    local success, message = deleteCharacter(src, characterId)
    if not success then
        TriggerClientEvent('QBCore:Notify', src, _U(message), 'error')
    else
        TriggerClientEvent('QBCore:Notify', src, _U('character_deleted'), 'success')
        -- Refresh character list
        TriggerClientEvent('irp-multicharacter:client:openSelection', src, getCharacterList(src))
    end
end)

-- Admin commands
QBCore.Commands.Add('addcharacterslot', 'Add extra character slot(s) to a player', {{name='id', help='Player ID'}, {name='amount', help='Number of slots to add'}}, false, function(source, args)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or (Player.PlayerData.permission ~= 'god' and Player.PlayerData.permission ~= 'admin') then
        TriggerClientEvent('QBCore:Notify', src, _U('no_permission'), 'error')
        return
    end
    local targetId = tonumber(args[1])
    local amount = tonumber(args[2])
    if not targetId or not amount or amount <= 0 then
        TriggerClientEvent('QBCore:Notify', src, _U('invalid_arguments'), 'error')
        return
    end
    local Target = QBCore.Functions.GetPlayer(targetId)
    if not Target then
        TriggerClientEvent('QBCore:Notify', src, _U('player_not_found'), 'error')
        return
    end
    local license = Target.PlayerData.license
    local existing = MySQL.single.await('SELECT extra_slots FROM player_extra_slots WHERE license = ?', { license })
    local newExtra = (existing and existing.extra_slots or 0) + amount
    MySQL.update.await('INSERT INTO player_extra_slots (license, extra_slots) VALUES (?, ?) ON DUPLICATE KEY UPDATE extra_slots = ?', { license, newExtra, newExtra })
    TriggerClientEvent('QBCore:Notify', src, 'Added ' .. amount .. ' slot(s) to player ' .. targetId, 'success')
end, 'admin')

QBCore.Commands.Add('removecharacterslot', 'Remove extra character slot(s) from a player', {{name='id', help='Player ID'}, {name='amount', help='Number of slots to remove'}}, false, function(source, args)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or (Player.PlayerData.permission ~= 'god' and Player.PlayerData.permission ~= 'admin') then
        TriggerClientEvent('QBCore:Notify', src, _U('no_permission'), 'error')
        return
    end
    local targetId = tonumber(args[1])
    local amount = tonumber(args[2])
    if not targetId or not amount or amount <= 0 then
        TriggerClientEvent('QBCore:Notify', src, _U('invalid_arguments'), 'error')
        return
    end
    local Target = QBCore.Functions.GetPlayer(targetId)
    if not Target then
        TriggerClientEvent('QBCore:Notify', src, _U('player_not_found'), 'error')
        return
    end
    local license = Target.PlayerData.license
    local existing = MySQL.single.await('SELECT extra_slots FROM player_extra_slots WHERE license = ?', { license })
    local currentExtra = existing and existing.extra_slots or 0
    local newExtra = math.max(0, currentExtra - amount)
    MySQL.update.await('INSERT INTO player_extra_slots (license, extra_slots) VALUES (?, ?) ON DUPLICATE KEY UPDATE extra_slots = ?', { license, newExtra, newExtra })
    TriggerClientEvent('QBCore:Notify', src, 'Removed ' .. amount .. ' slot(s) from player ' .. targetId, 'success')
end, 'admin')

-- Exports
exports('GetCharacterCount', function(src)
    return getCharacterCount(src)
end)
exports('GetMaxSlots', function(src)
    return getMaxSlots(src)
end)
exports('CreateCharacter', function(src, data)
    return createCharacter(src, data)
end)

-- Cleanup cooldowns on drop
AddEventHandler('playerDropped', function()
    cooldowns[source] = nil
    selectingCharacter[source] = nil
end)
