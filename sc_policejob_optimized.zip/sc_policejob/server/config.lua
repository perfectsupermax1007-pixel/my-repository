-- SERVER-ONLY config. This file is never sent to clients, so webhook URLs are safe here.
-- (They used to be in config.lua, which is a shared script: every player could read them.)

Config.Webhooks = {
    enabled = false,     -- flip to true once URLs below are filled in
    username = 'Second Chance PD',
    avatar = '',         -- optional image URL for the webhook avatar

    urls = {
        citations = '',  -- Discord webhook URL per category; blank = skip that category
        arrests   = '',
        bolos     = '',
        impounds  = '',
        duty      = '',
    },

    -- Discord embed colors are DECIMAL, not hex.
    colors = {
        citations = 3828696,  -- blue
        arrests   = 3828696,  -- blue
        warrant   = 13647930, -- red
        bolos     = 14718767, -- amber
        impounds  = 3828696,  -- blue
        duty      = 7108228,  -- muted grey-blue
    },
}

-- Old rows are pruned on resource start. 0 = keep forever.
Config.LogRetentionDays = {
    dispatch = 30,   -- pd_dispatch_log (alert feed; grows fastest)
    duty = 0,        -- pd_duty_log (audit trail; leaderboard totals are kept separately in pd_duty_totals)
}
