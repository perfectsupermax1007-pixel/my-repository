local QBCore = exports['qb-core']:GetCoreObject()

local Cuffed = {}        -- [src] = true
local ActiveBolos = {}   -- [id] = { subject = 'Name', lower = 'name' }
local DutySessions = {}  -- [src] = { startedAt, citizenid, name, rank }  (self-contained: survives Player object being gone on drop)
local Cooldowns = {}     -- [src] = { [key] = GetGameTimer() }

local ActionById = {}
for _, a in ipairs(Config.Actions) do ActionById[a.id] = a end

-- ============================================================
-- HELPERS
-- ============================================================
-- Everything a client sends is untrusted: coerce to a bounded, control-char-free string.
local function clean(v, max)
    v = tostring(v or ''):gsub('%c', ' '):gsub('^%s+', ''):gsub('%s+$', '')
    return v:sub(1, max or 255)
end

local function notify(src, msg, typ) TriggerClientEvent('QBCore:Notify', src, msg, typ or 'primary') end

local function isPolice(P) return P and P.PlayerData.job and P.PlayerData.job.name == Config.Job end
local function canAct(P)
    if not isPolice(P) then return false end
    return not Config.RequireOnDuty or P.PlayerData.job.onduty == true
end
local function gradeOf(P) return P.PlayerData.job.grade.level end
local function canWrite(P) return canAct(P) and gradeOf(P) >= Config.MDTWriteGrade end
local function fullName(P)
    local c = P.PlayerData.charinfo or {}
    return clean((c.firstname or '') .. ' ' .. (c.lastname or ''), 80)
end

local function throttled(src, key, ms)
    local now = GetGameTimer()
    local t = Cooldowns[src]
    if not t then t = {}; Cooldowns[src] = t end
    if t[key] and now - t[key] < (ms or Config.ActionCooldownMs) then return true end
    t[key] = now
    return false
end

-- Validates the caller may perform a field action (job, duty, grade, required item).
local function authorize(src, actionId)
    local Player = QBCore.Functions.GetPlayer(src)
    if not isPolice(Player) then return nil end
    if not canAct(Player) then notify(src, 'You must be on duty.', 'error') return nil end
    local a = ActionById[actionId]
    if a then
        if gradeOf(Player) < a.grade then return nil end
        if a.requiredItem then
            local it = Player.Functions.GetItemByName(a.requiredItem)
            if not it or it.amount < 1 then notify(src, 'You need: ' .. a.requiredItem, 'error') return nil end
        end
    end
    return Player
end

-- Resolves + range-checks a target player. Returns Target, targetSrc (or nil).
local function getTarget(src, targetSrc, maxDist)
    targetSrc = tonumber(targetSrc)
    if not targetSrc or targetSrc == src then return nil end
    local Target = QBCore.Functions.GetPlayer(targetSrc)
    if not Target then return nil end
    local a, b = GetPlayerPed(src), GetPlayerPed(targetSrc)
    if a == 0 or b == 0 or #(GetEntityCoords(a) - GetEntityCoords(b)) > maxDist then
        notify(src, 'Too far away.', 'error') return nil
    end
    return Target, targetSrc
end

local function onDutySources()
    local list = {}
    for _, P in pairs(QBCore.Functions.GetQBPlayers()) do
        local job = P.PlayerData.job
        if job.name == Config.Job and job.onduty then list[#list + 1] = P.PlayerData.source end
    end
    return list
end

-- Runs several queries concurrently and waits for all (1 round-trip of latency instead of N).
local function queryAll(queries)
    local results, pending, p = {}, #queries, promise.new()
    for i, q in ipairs(queries) do
        MySQL.query(q[1], q[2] or {}, function(r)
            results[i] = r or {}
            pending = pending - 1
            if pending == 0 then p:resolve(results) end
        end)
    end
    return Citizen.Await(p)
end

local function matchingActiveBolo(name)
    name = (name or ''):lower()
    for id, b in pairs(ActiveBolos) do
        if #b.lower >= 3 and name:find(b.lower, 1, true) then return id end
    end
end

-- ============================================================
-- DISCORD WEBHOOKS (config lives in server/config.lua)
-- ============================================================
local function field(name, value)
    value = clean(value, 1000)
    return { name = name, value = value ~= '' and value or '—', inline = true }
end

local function sendWebhook(category, title, description, fields, colorKey)
    local W = Config.Webhooks
    if not W or not W.enabled then return end
    local url = W.urls[category]
    if not url or url == '' then return end

    local payload = {
        username = W.username,
        allowed_mentions = { parse = {} }, -- player-controlled text must never ping anyone
        embeds = {{
            title = title,
            description = description and clean(description, 1000) or nil,
            color = W.colors[colorKey or category] or 3828696,
            fields = fields,
            footer = { text = 'Second Chance RP — sc_policejob' },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        }},
    }
    if (W.avatar or '') ~= '' then payload.avatar_url = W.avatar end
    PerformHttpRequest(url, function() end, 'POST', json.encode(payload), { ['Content-Type'] = 'application/json' })
end

-- ============================================================
-- DISPATCH BOARD
-- Toast goes out immediately; the DB write no longer blocks it.
-- ============================================================
local function pingDispatch(alertType, message, coords, officerSrc)
    alertType = clean(alertType, 20):lower():gsub('[^a-z]', '')
    if alertType == '' then alertType = 'citation' end
    message = clean(message, 255)

    local payload = { type = alertType, message = message, ts = os.time() }
    for _, src in ipairs(onDutySources()) do
        TriggerClientEvent('sc_policejob:client:dispatchAlert', src, payload)
    end
    MySQL.insert('INSERT INTO pd_dispatch_log (type, message) VALUES (?, ?)', { alertType, message })

    TriggerEvent(Config.DispatchEventName, {
        type = alertType, message = message, coords = coords, source = officerSrc,
    })
end

MySQL.ready(function()
    MySQL.query('SELECT id, subject FROM pd_bolos WHERE active = 1', {}, function(rows)
        for _, row in ipairs(rows or {}) do
            ActiveBolos[row.id] = { subject = row.subject, lower = (row.subject or ''):lower() }
        end
    end)

    local keep = Config.LogRetentionDays or {}
    if (keep.dispatch or 0) > 0 then
        MySQL.update('DELETE FROM pd_dispatch_log WHERE created_at < (NOW() - INTERVAL ? DAY)', { keep.dispatch })
    end
    if (keep.duty or 0) > 0 then
        MySQL.update('DELETE FROM pd_duty_log WHERE created_at < (NOW() - INTERVAL ? DAY)', { keep.duty })
    end
end)

-- ============================================================
-- DUTY + DUTY TIME LOGGING
-- clockOn/clockOff are idempotent, so the toggle event and the job-update /
-- logout / disconnect hooks can all call them safely.
-- ============================================================
local function formatDuration(totalSeconds)
    totalSeconds = math.max(0, math.floor(totalSeconds or 0))
    local h, m = math.floor(totalSeconds / 3600), math.floor((totalSeconds % 3600) / 60)
    if h > 0 then return ('%sh %sm'):format(h, m) end
    return ('%sm'):format(m)
end

local function clockOn(src, Player)
    if DutySessions[src] then return end
    local name, cid = fullName(Player), Player.PlayerData.citizenid
    DutySessions[src] = { startedAt = os.time(), citizenid = cid, name = name, rank = Player.PlayerData.job.grade.name }
    MySQL.insert('INSERT INTO pd_duty_log (citizenid, name, action, duration_seconds) VALUES (?, ?, ?, NULL)', { cid, name, 'on' })
    sendWebhook('duty', 'Officer Clocked On', nil, { field('Officer', name), field('Rank', DutySessions[src].rank) })
end

local function clockOff(src, reason)
    local s = DutySessions[src]
    if not s then return 0 end
    DutySessions[src] = nil
    local duration = os.time() - s.startedAt
    MySQL.insert('INSERT INTO pd_duty_log (citizenid, name, action, duration_seconds) VALUES (?, ?, ?, ?)', { s.citizenid, s.name, 'off', duration })
    MySQL.update(
        'INSERT INTO pd_duty_totals (citizenid, name, total_seconds) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE total_seconds = total_seconds + VALUES(total_seconds), name = VALUES(name)',
        { s.citizenid, s.name, duration })
    local title = reason == 'disconnect' and 'Officer Disconnected While On Duty'
        or reason == 'unload' and 'Officer Logged Out While On Duty'
        or reason == 'jobchange' and 'Officer Left Duty (Job Change)'
        or 'Officer Clocked Off'
    sendWebhook('duty', title, nil, { field('Officer', s.name), field('Rank', s.rank), field('Session Length', formatDuration(duration)) })
    return duration
end

RegisterNetEvent('sc_policejob:server:toggleDuty', function()
    local src = source
    if throttled(src, 'duty', 1000) then return end
    local Player = QBCore.Functions.GetPlayer(src)
    if not isPolice(Player) then return end

    Player.Functions.SetJobDuty(not Player.PlayerData.job.onduty)
    if Player.PlayerData.job.onduty then
        clockOn(src, Player)
        notify(src, 'You are now on duty.')
    else
        clockOff(src)
        notify(src, 'You are now off duty.')
    end
end)

-- Duty changed elsewhere (admin, another resource) or job changed while on duty: don't leak the session.
AddEventHandler('QBCore:Server:OnJobUpdate', function(src, job)
    if DutySessions[src] and (not job or job.name ~= Config.Job or not job.onduty) then
        clockOff(src, (job and job.name ~= Config.Job) and 'jobchange' or nil)
    end
end)

local function cleanupPlayer(src, reason)
    clockOff(src, reason)
    Cuffed[src], Cooldowns[src] = nil, nil
end
AddEventHandler('playerDropped', function() cleanupPlayer(source, 'disconnect') end)
AddEventHandler('QBCore:Server:OnPlayerUnload', function(src) cleanupPlayer(src, 'unload') end)

QBCore.Functions.CreateCallback('sc_policejob:server:getDutyLog', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not isPolice(Player) then cb(nil) return end
    local r = queryAll({
        { 'SELECT name, action, duration_seconds, created_at FROM pd_duty_log ORDER BY id DESC LIMIT 50' },
        { 'SELECT name, total_seconds FROM pd_duty_totals ORDER BY total_seconds DESC LIMIT 15' },
    })
    local s = DutySessions[source]
    cb({ log = r[1], totals = r[2], myCurrentSessionSeconds = s and (os.time() - s.startedAt) or 0 })
end)

-- ============================================================
-- TOOL DATA
-- ============================================================
QBCore.Functions.CreateCallback('sc_policejob:server:getTools', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not isPolice(Player) then cb(nil) return end
    local grade = gradeOf(Player)

    local actions = {}
    for _, a in ipairs(Config.Actions) do
        local hasItem = true
        if a.requiredItem then
            local inv = Player.Functions.GetItemByName(a.requiredItem)
            hasItem = inv ~= nil and inv.amount > 0
        end
        actions[#actions + 1] = {
            id = a.id, label = a.label, description = a.description, icon = a.icon, duration = a.duration,
            requiredItem = a.requiredItem, action = a.action, unlocked = grade >= a.grade, hasItem = hasItem, requiredGrade = a.grade,
        }
    end
    local utilities = {}
    for _, u in ipairs(Config.Utilities) do
        utilities[#utilities + 1] = { id = u.id, label = u.label, description = u.description, icon = u.icon, unlocked = grade >= u.grade, requiredGrade = u.grade }
    end

    cb({
        gradeLabel = Player.PlayerData.job.grade.name, grade = grade, onDuty = Player.PlayerData.job.onduty,
        actions = actions, utilities = utilities,
        violations = Config.Violations, charges = Config.Charges, -- the pickers were empty before: these were never sent
    })
end)

-- ============================================================
-- CUFF / SEARCH
-- ============================================================
RegisterNetEvent('sc_policejob:server:cuff', function(targetSrc)
    local src = source
    if throttled(src, 'cuff') then return end
    local Player = authorize(src, 'cuff'); if not Player then return end
    local Target, tid = getTarget(src, targetSrc, 3.0); if not Target then return end

    Cuffed[tid] = not Cuffed[tid] or nil
    TriggerClientEvent('sc_policejob:client:setCuffed', tid, Cuffed[tid] == true)
    notify(src, Cuffed[tid] and 'Suspect cuffed.' or 'Suspect uncuffed.', 'success')
end)

RegisterNetEvent('sc_policejob:server:search', function(targetSrc)
    local src = source
    if throttled(src, 'search') then return end
    local Player = authorize(src, 'search'); if not Player then return end
    local Target = getTarget(src, targetSrc, 3.0); if not Target then return end

    local items = {}
    for _, item in pairs(Target.PlayerData.items or {}) do
        if item then items[#items + 1] = { name = item.label or item.name, amount = item.amount } end
    end
    TriggerClientEvent('sc_policejob:client:showSearch', src, fullName(Target), items)
end)

-- ============================================================
-- CITATION
-- ============================================================
RegisterNetEvent('sc_policejob:server:citation', function(targetSrc, violationIndex)
    local src = source
    if throttled(src, 'citation') then return end
    local Player = QBCore.Functions.GetPlayer(src)
    if not canWrite(Player) then notify(src, 'Not authorized to issue citations.', 'error') return end
    local v = Config.Violations[math.floor(tonumber(violationIndex) or 0)]
    if not v then return end
    local Target, tid = getTarget(src, targetSrc, 4.0); if not Target then return end

    local paid = Target.Functions.RemoveMoney('bank', v.fine, 'citation-fine')
        or Target.Functions.RemoveMoney('cash', v.fine, 'citation-fine')
    local officer, citizen = fullName(Player), fullName(Target)

    notify(tid, ('You were fined $%s for %s.'):format(v.fine, v.label), 'error')
    MySQL.insert(
        'INSERT INTO pd_citations (officer, officer_cid, citizen_name, citizen_cid, violation, fine) VALUES (?, ?, ?, ?, ?, ?)',
        { officer, Player.PlayerData.citizenid, citizen, Target.PlayerData.citizenid, v.label, v.fine })
    pingDispatch('citation', ('%s cited %s for %s ($%s)'):format(officer, citizen, v.label, v.fine), GetEntityCoords(GetPlayerPed(tid)), src)
    sendWebhook('citations', 'Citation Issued', nil, {
        field('Officer', officer), field('Citizen', citizen), field('Violation', v.label), field('Fine', '$' .. v.fine),
    })
    notify(src, ('Citation issued: %s ($%s)%s.'):format(v.label, v.fine, paid and '' or ' — citizen could not pay'), paid and 'success' or 'primary')
end)

-- ============================================================
-- ARREST
-- ============================================================
RegisterNetEvent('sc_policejob:server:arrest', function(targetSrc, chargeIndex)
    local src = source
    if throttled(src, 'arrest') then return end
    local Player = authorize(src, 'arrest'); if not Player then return end
    local charge = Config.Charges[math.floor(tonumber(chargeIndex) or 0)]
    if not charge then return end
    local Target, tid = getTarget(src, targetSrc, 3.0); if not Target then return end
    if not Cuffed[tid] then notify(src, 'Suspect must be cuffed first.', 'error') return end

    local officer, suspectName = fullName(Player), fullName(Target)
    local boloId = matchingActiveBolo(suspectName)
    if boloId then
        ActiveBolos[boloId] = nil
        -- was only cleared in memory before, so served BOLOs reappeared in the MDT / after restart
        MySQL.update('UPDATE pd_bolos SET active = 0 WHERE id = ?', { boloId })
    end

    Cuffed[tid] = nil
    TriggerClientEvent('sc_policejob:client:sendToHolding', tid, charge.minutes)

    MySQL.insert(
        'INSERT INTO pd_arrests (officer, officer_cid, suspect_name, suspect_cid, charges, was_warrant) VALUES (?, ?, ?, ?, ?, ?)',
        { officer, Player.PlayerData.citizenid, suspectName, Target.PlayerData.citizenid, charge.label, boloId and 1 or 0 })
    pingDispatch(boloId and 'warrant' or 'arrest',
        boloId and ('WARRANT SERVED — %s booked %s (%s)'):format(officer, suspectName, charge.label)
                or ('%s booked %s on %s'):format(officer, suspectName, charge.label),
        GetEntityCoords(GetPlayerPed(tid)), src)
    sendWebhook('arrests', boloId and 'Warrant Served' or 'Arrest Made', nil, {
        field('Officer', officer), field('Suspect', suspectName), field('Charge', charge.label), field('Holding Time', charge.minutes .. ' min'),
    }, boloId and 'warrant' or 'arrests')
    notify(src, ('Booked %s on %s%s.'):format(suspectName, charge.label, boloId and ' (warrant served)' or ''), 'success')
end)

-- ============================================================
-- SEIZE / IMPOUND
-- ============================================================
RegisterNetEvent('sc_policejob:server:seize', function(targetSrc)
    local src = source
    if throttled(src, 'seize') then return end
    local Player = authorize(src, 'seize'); if not Player then return end
    local Target, tid = getTarget(src, targetSrc, 3.0); if not Target then return end

    local seized = 0
    for _, item in pairs(Target.PlayerData.items or {}) do
        if item and item.name and item.name:find('^weapon_') then
            Target.Functions.RemoveItem(item.name, item.amount, item.slot)
            seized = seized + 1
        end
    end
    notify(src, ('Seized %s weapon item(s).'):format(seized), 'success')
    if seized > 0 then notify(tid, 'Your weapons were seized.', 'error') end
end)

-- The client only supplies a network id. Everything else is verified/read here:
-- before, any grade-1 officer could delete ANY entity by id from anywhere, and forge the plate.
local function validateImpoundVehicle(src, netId)
    netId = tonumber(netId)
    if not netId then return nil end
    local veh = NetworkGetEntityFromNetworkId(netId)
    if not veh or veh == 0 or not DoesEntityExist(veh) or GetEntityType(veh) ~= 2 then return nil end
    if #(GetEntityCoords(GetPlayerPed(src)) - GetEntityCoords(veh)) > 15.0 then notify(src, 'Too far away.', 'error') return nil end
    if GetPedInVehicleSeat(veh, -1) ~= 0 then notify(src, 'Vehicle is occupied.', 'error') return nil end
    local plate = clean(GetVehicleNumberPlateText(veh), 15)
    return veh, (plate ~= '' and plate or 'UNKNOWN')
end

local function logImpound(src, Player, plate)
    MySQL.insert('INSERT INTO pd_impounds (officer, officer_cid, plate) VALUES (?, ?, ?)', { fullName(Player), Player.PlayerData.citizenid, plate })
    pingDispatch('impound', ('%s impounded a vehicle (%s)'):format(fullName(Player), plate), GetEntityCoords(GetPlayerPed(src)), src)
    sendWebhook('impounds', 'Vehicle Impounded', nil, { field('Officer', fullName(Player)), field('Plate', plate) })
end

RegisterNetEvent('sc_policejob:server:impound', function(netId)
    local src = source
    if throttled(src, 'impound', 2000) then return end
    local Player = authorize(src, 'impound'); if not Player then return end
    local veh, plate = validateImpoundVehicle(src, netId); if not veh then return end
    DeleteEntity(veh)
    logImpound(src, Player, plate)
    notify(src, 'Vehicle impounded.', 'success')
end)

-- Paper-trail-only variant for when jg-advancedgarages does the removal itself.
RegisterNetEvent('sc_policejob:server:logImpound', function(netId)
    local src = source
    if throttled(src, 'impound', 2000) then return end
    local Player = authorize(src, 'impound'); if not Player then return end
    local veh, plate = validateImpoundVehicle(src, netId); if not veh then return end
    logImpound(src, Player, plate)
end)

-- ============================================================
-- ARMORY
-- Was broken: read Config.ArmoryAccess / ArmoryAmmoPerWeapon which don't exist in config.lua,
-- and the 'ALL' rank accepted ANY item name from the client.
-- ============================================================
local ArmoryCache = {}   -- [grade] = { list = {{name,label,amount}}, set = {[name]=amount} }

local function armoryFor(grade)
    if ArmoryCache[grade] then return ArmoryCache[grade] end
    local src = Config.Armory[grade] or Config.Armory[0] or {}
    local list, set = {}, {}
    local function add(name, amount)
        if set[name] then return end
        set[name] = amount or 1
        local it = QBCore.Shared.Items[name]
        list[#list + 1] = { name = name, label = it and it.label or name, amount = amount }
    end
    for _, w in ipairs(src) do
        if w == 'ALL' then for _, a in ipairs(Config.ArmoryAllWeapons) do add(a) end else add(w) end
    end
    for _, u in ipairs(Config.ArmoryUtilityItems or {}) do add(u.item, u.amount) end
    ArmoryCache[grade] = { list = list, set = set }
    return ArmoryCache[grade]
end

local function nearArmory(src)
    local pc = GetEntityCoords(GetPlayerPed(src))
    for _, st in pairs(Config.Stations) do
        if #(pc - st.armory) <= Config.ArmoryUseDistance then return true end
    end
    return false
end

QBCore.Functions.CreateCallback('sc_policejob:server:getArmory', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not canAct(Player) then cb(nil) return end
    cb({ items = armoryFor(gradeOf(Player)).list })
end)

RegisterNetEvent('sc_policejob:server:takeWeapon', function(itemName)
    local src = source
    if throttled(src, 'armory', 500) then return end
    local Player = QBCore.Functions.GetPlayer(src)
    if not canAct(Player) then return end
    if type(itemName) ~= 'string' then return end
    local amount = armoryFor(gradeOf(Player)).set[itemName]
    if not amount then notify(src, 'Not cleared for that item at your rank.', 'error') return end
    if not nearArmory(src) then return end

    if not Player.Functions.AddItem(itemName, amount) then notify(src, 'You cannot carry that.', 'error') return end
    local item = QBCore.Shared.Items[itemName]
    if item then TriggerClientEvent('inventory:client:ItemBox', src, item, 'add', amount) end

    local ammoItem = Config.ArmoryAmmo[itemName]
    if ammoItem and QBCore.Shared.Items[ammoItem] then
        Player.Functions.AddItem(ammoItem, Config.ArmoryAmmoPerWeapon)
    end
    notify(src, 'Issued from the armory.', 'success')
end)

-- ============================================================
-- VEHICLE SPAWNER (Config.Garage, minGrade is inherently cumulative)
-- ============================================================
QBCore.Functions.CreateCallback('sc_policejob:server:getVehicles', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not canAct(Player) then cb(nil) return end
    local grade, list = gradeOf(Player), {}
    for _, v in ipairs(Config.Garage) do
        if grade >= (v.minGrade or 0) then list[#list + 1] = { model = v.model, label = v.label } end
    end
    cb({ vehicles = list })
end)

-- ============================================================
-- BOLO
-- ============================================================
local function createBolo(officerName, officerCid, subject, plate, reason, coords, src)
    subject, plate, reason = clean(subject, 60), clean(plate, 15), clean(reason, 200)
    if subject == '' then return end
    MySQL.insert(
        'INSERT INTO pd_bolos (officer, officer_cid, subject, plate, reason, active) VALUES (?, ?, ?, ?, ?, 1)',
        { officerName, officerCid, subject, plate, reason },
        function(id)
            ActiveBolos[id] = { subject = subject, lower = subject:lower() }
            pingDispatch('bolo', ('BOLO — %s: %s%s'):format(subject, reason ~= '' and reason or 'no details given', plate ~= '' and (' (plate ' .. plate .. ')') or ''), coords, src)
            sendWebhook('bolos', 'BOLO Filed', reason ~= '' and reason or nil, {
                field('Subject', subject), field('Plate', plate), field('Filed By', officerName),
            })
            if src then notify(src, 'BOLO filed.', 'success') end
        end)
end

RegisterNetEvent('sc_policejob:server:fileBolo', function(subject, plate, reason)
    local src = source
    if throttled(src, 'bolo', 3000) then return end
    local Player = QBCore.Functions.GetPlayer(src)
    -- README promised grade-gated (server-enforced) filing; the old code only checked "is police"
    if not canWrite(Player) then notify(src, 'Not authorized to file BOLOs.', 'error') return end
    createBolo(fullName(Player), Player.PlayerData.citizenid, subject, plate, reason, GetEntityCoords(GetPlayerPed(src)), src)
end)

-- ============================================================
-- MDT
-- ============================================================
QBCore.Functions.CreateCallback('sc_policejob:server:getMDT', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not isPolice(Player) then cb(nil) return end

    local limit = Config.MDT.recordsPerPage
    local r = queryAll({
        { 'SELECT officer, citizen_name, violation, fine, created_at FROM pd_citations ORDER BY id DESC LIMIT ?', { limit } },
        { 'SELECT officer, suspect_name, charges, was_warrant, created_at FROM pd_arrests ORDER BY id DESC LIMIT ?', { limit } },
        { 'SELECT officer, subject, plate, reason, created_at FROM pd_bolos WHERE active = 1 ORDER BY id DESC' },
    })

    local roster = {}
    for _, P in pairs(QBCore.Functions.GetQBPlayers()) do
        local job = P.PlayerData.job
        if job.name == Config.Job and job.onduty then
            roster[#roster + 1] = { name = fullName(P), grade = job.grade.name, callsign = clean((P.PlayerData.metadata or {}).callsign or '—', 20) }
        end
    end
    cb({ canWrite = canWrite(Player), myName = fullName(Player), citations = r[1], arrests = r[2], bolos = r[3], roster = roster })
end)

QBCore.Functions.CreateCallback('sc_policejob:server:searchRecords', function(source, cb, query)
    local Player = QBCore.Functions.GetPlayer(source)
    if not isPolice(Player) then cb({}) return end
    query = clean(query, 60)
    if #query < 2 then cb({}) return end
    local like = '%' .. query:gsub('[\\%%_]', '\\%0') .. '%'   -- user text must not act as LIKE wildcards
    MySQL.query(
        "SELECT 'citation' AS kind, citizen_name AS name, violation AS detail, fine AS extra, created_at, officer AS author FROM pd_citations WHERE citizen_name LIKE ? " ..
        "UNION ALL SELECT 'arrest' AS kind, suspect_name AS name, charges AS detail, NULL AS extra, created_at, officer AS author FROM pd_arrests WHERE suspect_name LIKE ? " ..
        'ORDER BY created_at DESC LIMIT 50', { like, like },
        function(result) cb(result or {}) end)
end)

QBCore.Functions.CreateCallback('sc_policejob:server:getDispatchLog', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not isPolice(Player) then cb({}) return end
    MySQL.query('SELECT type, message, created_at FROM pd_dispatch_log ORDER BY id DESC LIMIT ?', { Config.DispatchLogLimit },
        function(result) cb(result or {}) end)
end)

-- ============================================================
-- EXPORTS
-- ============================================================
exports('GetOnDutyCount', function() return #onDutySources() end)

exports('IsCuffed', function(src) return Cuffed[src] == true end)

exports('GetActiveBolos', function()
    local list = {}
    for id, b in pairs(ActiveBolos) do list[#list + 1] = { id = id, subject = b.subject } end
    return list
end)

exports('FileBolo', function(officerName, officerCid, subject, plate, reason)
    createBolo(clean(officerName, 80), clean(officerCid, 50), subject, plate, reason, nil, nil)
end)

exports('SendDispatchAlert', function(alertType, message, coords, officerSrc)
    pingDispatch(alertType, message, coords, officerSrc)
end)

-- The two lookups below keep their callback form, and also work synchronously when no callback is given.
local function dutyTotal(citizenid)
    return MySQL.scalar.await('SELECT total_seconds FROM pd_duty_totals WHERE citizenid = ?', { citizenid }) or 0
end
exports('GetDutyTotal', function(citizenid, cb)
    if type(cb) ~= 'function' then return dutyTotal(citizenid) end
    CreateThread(function() cb(dutyTotal(citizenid)) end)
end)

exports('GetCurrentSessionSeconds', function(src)
    local s = DutySessions[src]
    return s and (os.time() - s.startedAt) or 0
end)

local function citizenRecord(citizenid)   -- 1 query instead of 2 nested ones
    local r = MySQL.single.await(
        'SELECT (SELECT COUNT(*) FROM pd_arrests WHERE suspect_cid = ?) AS arrests, (SELECT COUNT(*) FROM pd_citations WHERE citizen_cid = ?) AS citations',
        { citizenid, citizenid })
    return { arrests = r and r.arrests or 0, citations = r and r.citations or 0 }
end
exports('GetCitizenRecord', function(citizenid, cb)
    if type(cb) ~= 'function' then return citizenRecord(citizenid) end
    CreateThread(function() cb(citizenRecord(citizenid)) end)
end)
