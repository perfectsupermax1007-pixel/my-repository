-- Run ONCE on an existing 1.0.0 database (install.sql already has these for fresh installs).
-- If a statement errors with "Duplicate key name", that index already exists: skip it.
CREATE INDEX idx_cit_cid ON pd_citations (citizen_cid);          -- GetCitizenRecord export
CREATE INDEX idx_arr_cid ON pd_arrests (suspect_cid);            -- GetCitizenRecord export
CREATE INDEX idx_bolo_active ON pd_bolos (active);               -- MDT active-BOLO list / startup load
CREATE INDEX idx_dispatch_created ON pd_dispatch_log (created_at); -- log pruning
CREATE INDEX idx_duty_created ON pd_duty_log (created_at);       -- log pruning
CREATE INDEX idx_totals_seconds ON pd_duty_totals (total_seconds); -- leaderboard

-- Served warrants used to stay active=1 forever (only cleared in memory). Optional cleanup:
-- UPDATE pd_bolos b JOIN pd_arrests a ON a.suspect_name LIKE CONCAT('%', b.subject, '%') AND a.was_warrant = 1 AND a.created_at >= b.created_at SET b.active = 0;
