local QBCore = exports['qb-core']:GetCoreObject()

local uiOpen = nil        -- nil | 'tools' | 'mdt' | 'armory' | 'garage' | 'search'  (replaces 4 separate booleans)
local isPD = false        -- only police run the interaction loop / get prompts
local isCuffed = false
local holdingToken = 0    -- incremented per arrest; old holding threads exit when it changes
local MyProps = {}
local pendingSpawn, allowedModels = nil, {}

local ActionById = {}
for _, a in ipairs(Config.Actions) do ActionById[a.id] = a end

local openArmory, openVehicleMenu -- forward declarations (were accidental globals before)

-- ============================================================
-- HELPERS
-- ============================================================
local function setUI(kind)
    uiOpen = kind
    SetNuiFocus(kind ~= nil, kind ~= nil)
end

local function closeUI()
    setUI(nil)
    SendNUIMessage({ action = 'close' })
end

local function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35); SetTextFont(4); SetTextCentre(true)
    SetTextColour(255, 255, 255, 215); SetTextEntry('STRING')
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0); DrawText(0.0, 0.0); ClearDrawOrigin()
end

local function loadAnim(dict)
    if HasAnimDictLoaded(dict) then return true end
    RequestAnimDict(dict)
    local t = 0
    while not HasAnimDictLoaded(dict) and t < 50 do Wait(50); t = t + 1 end
    return HasAnimDictLoaded(dict)
end

local function loadModel(hash, tries)
    if not IsModelInCdimage(hash) then return false end
    RequestModel(hash)
    local t = 0
    while not HasModelLoaded(hash) and t < (tries or 100) do Wait(50); t = t + 1 end
    return HasModelLoaded(hash)
end

-- One NUI message; the bar animates in CSS. (Was a message every 50ms for the whole duration.)
local function progress(label, duration, dict, anim)
    if dict and loadAnim(dict) then
        TaskPlayAnim(PlayerPedId(), dict, anim, 3.0, -3.0, -1, 49, 0, false, false, false)
    end
    SendNUIMessage({ action = 'progress', label = label, duration = duration })
    Wait(duration)
    SendNUIMessage({ action = 'progressDone' })
    ClearPedTasks(PlayerPedId())
end

local function nearestPlayer(maxDist)
    local me = PlayerPedId()
    local mc = GetEntityCoords(me)
    local bestId, bestDist = nil, maxDist or 3.0
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= me and DoesEntityExist(ped) then
            local d = #(mc - GetEntityCoords(ped))
            if d < bestDist then bestId, bestDist = GetPlayerServerId(pid), d end
        end
    end
    return bestId
end

-- ============================================================
-- JOB TRACKING (prompts/loops only run for police)
-- ============================================================
local function refreshJob()
    local ok, pd = pcall(QBCore.Functions.GetPlayerData)
    isPD = ok and pd and pd.job and pd.job.name == Config.Job or false
end

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function() SetTimeout(1000, refreshJob) end)
RegisterNetEvent('QBCore:Client:OnPlayerUnload', function() isPD = false end)
RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job) isPD = job ~= nil and job.name == Config.Job end)
CreateThread(refreshJob)

-- ============================================================
-- STATION BLIPS + PROXIMITY INTERACTIONS
-- ============================================================
local Points = {}
for _, st in pairs(Config.Stations) do
    local b = st.blip or {}
    local blip = AddBlipForCoord(st.duty.x, st.duty.y, st.duty.z)
    SetBlipSprite(blip, b.sprite or 60)
    SetBlipColour(blip, b.color or 29)
    SetBlipScale(blip, b.scale or 0.8)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(st.label)
    EndTextCommandSetBlipName(blip)

    Points[#Points + 1] = { kind = 'duty',   pos = st.duty,   text = '[~b~E~s~] Toggle Duty' }
    Points[#Points + 1] = { kind = 'armory', pos = st.armory, text = '[~b~E~s~] Armory' }
    -- Config defines `garage` as a vector4; the old code read a nonexistent `st.vehicle` list and crashed this loop
    Points[#Points + 1] = { kind = 'garage', pos = vector3(st.garage.x, st.garage.y, st.garage.z), spawn = st.garage, text = '[~b~E~s~] Request Vehicle' }
end

CreateThread(function()
    while true do
        local sleep = 3000                       -- not police: basically idle
        if isPD then
            sleep = 1000
            if not uiOpen and not isCuffed then
                local pc = GetEntityCoords(PlayerPedId())
                local nearest = 9999.0
                for i = 1, #Points do
                    local p = Points[i]
                    local d = #(pc - p.pos)
                    if d < nearest then nearest = d end
                    if d < 8.0 then
                        sleep = 0                -- only tick every frame while a prompt is actually on screen
                        DrawText3D(p.pos.x, p.pos.y, p.pos.z + 1.0, p.text)
                        if d < 3.0 and IsControlJustReleased(0, 38) then
                            if p.kind == 'duty' then TriggerServerEvent('sc_policejob:server:toggleDuty')
                            elseif p.kind == 'armory' then openArmory()
                            else openVehicleMenu(p.spawn) end
                        end
                    end
                end
                if sleep ~= 0 then sleep = nearest < 40.0 and 250 or 1000 end
            else
                sleep = 250
            end
        end
        Wait(sleep)
    end
end)

-- ============================================================
-- CUFFED STATE
-- ============================================================
local function applyCuffed(state)
    isCuffed = state
    local ped = PlayerPedId()
    if state then
        if loadAnim('mp_arresting') then
            TaskPlayAnim(ped, 'mp_arresting', 'idle', 8.0, -8.0, -1, 49, 0, false, false, false)
        end
        DisablePlayerFiring(PlayerId(), true)
        SetEnableHandcuffs(ped, true)
    else
        ClearPedTasks(ped)
        SetEnableHandcuffs(ped, false)
    end
end

RegisterNetEvent('sc_policejob:client:setCuffed', applyCuffed)

CreateThread(function()
    local nextAnimCheck = 0
    while true do
        if isCuffed then
            DisableControlAction(0, 24, true); DisableControlAction(0, 25, true)
            DisableControlAction(0, 47, true); DisableControlAction(0, 58, true)
            DisableControlAction(0, 263, true); DisableControlAction(0, 264, true)
            DisableControlAction(0, 22, true)
            -- restore the cuffed pose if something (ragdoll, vehicle exit) knocked it off
            local now = GetGameTimer()
            if now > nextAnimCheck then
                nextAnimCheck = now + 1000
                local ped = PlayerPedId()
                if not IsEntityPlayingAnim(ped, 'mp_arresting', 'idle', 3) and not IsPedInAnyVehicle(ped, false) then
                    TaskPlayAnim(ped, 'mp_arresting', 'idle', 8.0, -8.0, -1, 49, 0, false, false, false)
                end
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- ============================================================
-- HOLDING CELL
-- One thread per arrest, only alive while someone is actually held.
-- (Was a permanent 500ms thread for every player + a NUI message every second.)
-- ============================================================
RegisterNetEvent('sc_policejob:client:sendToHolding', function(minutes)
    -- The server clears its cuffed flag on booking; clear ours too. Previously prisoners
    -- stayed cuffed through holding AND after release.
    if isCuffed then applyCuffed(false) end

    local hc = Config.HoldingCell
    local hcPos = vector3(hc.x, hc.y, hc.z)
    local ped = PlayerPedId()
    SetEntityCoordsNoOffset(ped, hc.x, hc.y, hc.z, false, false, false)
    SetEntityHeading(ped, hc.w)

    holdingToken = holdingToken + 1
    local token = holdingToken
    SendNUIMessage({ action = 'openHolding', minutes = minutes }) -- NUI counts down by itself

    CreateThread(function()
        local endAt = GetGameTimer() + minutes * 60000
        while holdingToken == token and GetGameTimer() < endAt do
            Wait(1000)
            if #(GetEntityCoords(PlayerPedId()) - hcPos) > 15.0 then
                SetEntityCoordsNoOffset(PlayerPedId(), hc.x, hc.y, hc.z, false, false, false)
            end
        end
        if holdingToken == token then
            SendNUIMessage({ action = 'closeHolding' })
            QBCore.Functions.Notify('You have been released.', 'primary')
        end
    end)
end)

-- ============================================================
-- PANELS
-- ============================================================
RegisterCommand('policejob', function()
    if uiOpen or not isPD then return end
    QBCore.Functions.TriggerCallback('sc_policejob:server:getTools', function(data)
        if not data then QBCore.Functions.Notify('You are not PD.', 'error') return end
        setUI('tools')
        SendNUIMessage({ action = 'openTools', data = data })
    end)
end, false)
RegisterKeyMapping('policejob', 'Police — Open Tools', 'keyboard', Config.ToolsKey)

RegisterCommand('policejobmdt', function()
    if uiOpen or not isPD then return end
    QBCore.Functions.TriggerCallback('sc_policejob:server:getMDT', function(data)
        if not data then QBCore.Functions.Notify('You are not PD.', 'error') return end
        setUI('mdt')
        SendNUIMessage({ action = 'openMDT', data = data })
    end)
end, false)
RegisterKeyMapping('policejobmdt', 'Police — Open MDT', 'keyboard', Config.MDTKey)

RegisterNUICallback('close', function(_, cb)
    setUI(nil)
    cb('ok')
end)

-- ============================================================
-- ACTIONS
-- ============================================================
RegisterNUICallback('action', function(data, cb)
    cb('ok')
    local a = ActionById[data.id]                       -- duration/label come from config, not from the NUI payload
    if not a or a.action == 'citation' or a.action == 'arrest' then return end -- pickers handle those

    closeUI()

    local targetId = nearestPlayer(3.0)
    if not targetId and a.action ~= 'impound' then
        QBCore.Functions.Notify('Nobody nearby.', 'error') return
    end

    CreateThread(function()
        if a.action == 'cuff' then
            progress(a.label, a.duration, 'mp_arresting', 'a_uncuff')
            TriggerServerEvent('sc_policejob:server:cuff', targetId)
        elseif a.action == 'search' then
            progress(a.label, a.duration)
            TriggerServerEvent('sc_policejob:server:search', targetId)
        elseif a.action == 'seize' then
            progress(a.label, a.duration)
            TriggerServerEvent('sc_policejob:server:seize', targetId)
        elseif a.action == 'impound' then
            local veh = GetClosestVehicle(GetEntityCoords(PlayerPedId()), 8.0, 0, 71)
            if veh == 0 or not DoesEntityExist(veh) or not IsVehicleSeatFree(veh, -1) or GetVehicleNumberOfPassengers(veh) > 0 then
                QBCore.Functions.Notify('No empty vehicle in reach.', 'error') return
            end
            local netId = NetworkGetNetworkIdFromEntity(veh)   -- server reads the plate itself now
            progress(a.label, a.duration)

            local jg = Config.JGGarageIntegration
            if jg.enabled and GetResourceState('jg-advancedgarages') == 'started' then
                -- defer persistence to JG's own event/UI (see config.lua for why we don't write its DB)
                TriggerServerEvent('sc_policejob:server:logImpound', netId)
                TriggerEvent('jg-advancedgarages:client:store-vehicle', jg.garageId, jg.vehicleType)
            else
                TriggerServerEvent('sc_policejob:server:impound', netId)
            end
        end
    end)
end)

-- Pickers: release NUI focus here. Before, focus stayed on with no visible UI (cursor stuck on screen).
RegisterNUICallback('issueCitation', function(data, cb)
    cb('ok')
    setUI(nil)
    local targetId = nearestPlayer(4.0)
    if not targetId then QBCore.Functions.Notify('Nobody nearby.', 'error') return end
    CreateThread(function()
        progress('Writing citation…', 4000)
        TriggerServerEvent('sc_policejob:server:citation', targetId, data.index and (data.index + 1))
    end)
end)

RegisterNUICallback('confirmArrest', function(data, cb)
    cb('ok')
    setUI(nil)
    local targetId = nearestPlayer(3.0)
    if not targetId then QBCore.Functions.Notify('Nobody nearby.', 'error') return end
    CreateThread(function()
        progress('Booking suspect…', 6000, 'mp_arresting', 'idle_2_cuffed')
        TriggerServerEvent('sc_policejob:server:arrest', targetId, data.index and (data.index + 1))
    end)
end)

-- Search results need focus to be closable (they were shown with focus already released => stuck panel)
RegisterNetEvent('sc_policejob:client:showSearch', function(name, items)
    setUI('search')
    SendNUIMessage({ action = 'showSearch', name = name, items = items })
end)

-- ============================================================
-- DISPATCH BOARD
-- ============================================================
RegisterNetEvent('sc_policejob:client:dispatchAlert', function(payload)
    SendNUIMessage({ action = 'dispatchToast', data = payload, ttl = Config.DispatchToastSeconds * 1000 })
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
end)

RegisterNUICallback('getDispatchLog', function(_, cb)
    QBCore.Functions.TriggerCallback('sc_policejob:server:getDispatchLog', function(results) cb({ results = results }) end)
end)

-- ============================================================
-- UTILITIES (scene props)
-- ============================================================
local function placeProp(modelName)
    local hash = GetHashKey(modelName)
    if not loadModel(hash, 60) then return end
    local ped = PlayerPedId()
    local coords = GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.2, 0.0)
    local obj = CreateObject(hash, coords.x, coords.y, coords.z, true, true, false)
    SetEntityHeading(obj, GetEntityHeading(ped))
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)
    SetModelAsNoLongerNeeded(hash)

    MyProps[#MyProps + 1] = obj
    while #MyProps > Config.MaxProps do                  -- cap: unlimited props = unlimited networked entities
        local old = table.remove(MyProps, 1)
        if DoesEntityExist(old) then DeleteObject(old) end
    end
end

RegisterNUICallback('utility', function(data, cb)
    cb('ok')
    closeUI()
    if data.id == 'toggle_duty' then
        TriggerServerEvent('sc_policejob:server:toggleDuty')
    elseif data.id == 'clear_props' then
        for _, obj in ipairs(MyProps) do if DoesEntityExist(obj) then DeleteObject(obj) end end
        MyProps = {}
        QBCore.Functions.Notify('Scene props cleared.', 'success')
    elseif Config.PropModels[data.id] then
        CreateThread(function() placeProp(Config.PropModels[data.id]) end)
    end
end)

-- ============================================================
-- ARMORY
-- ============================================================
openArmory = function()
    if uiOpen then return end
    QBCore.Functions.TriggerCallback('sc_policejob:server:getArmory', function(data)
        if not data then QBCore.Functions.Notify('Armory unavailable — are you on duty?', 'error') return end
        setUI('armory')
        SendNUIMessage({ action = 'openArmory', data = data })
    end)
end

RegisterNUICallback('takeWeapon', function(data, cb)
    if uiOpen == 'armory' and type(data.item) == 'string' then
        TriggerServerEvent('sc_policejob:server:takeWeapon', data.item)
    end
    cb('ok')
end)

-- ============================================================
-- VEHICLE SPAWNER
-- ============================================================
openVehicleMenu = function(spawnPoint)
    if uiOpen then return end
    QBCore.Functions.TriggerCallback('sc_policejob:server:getVehicles', function(data)
        if not data then QBCore.Functions.Notify('Fleet unavailable — are you on duty?', 'error') return end
        allowedModels = {}
        for _, v in ipairs(data.vehicles) do allowedModels[v.model] = true end
        pendingSpawn = spawnPoint
        setUI('garage')
        SendNUIMessage({ action = 'openGarage', data = data })
    end)
end

RegisterNUICallback('spawnVehicle', function(data, cb)
    cb('ok')
    local sp, model = pendingSpawn, data.model
    pendingSpawn = nil
    closeUI()

    if not sp or type(model) ~= 'string' or not allowedModels[model] then return end
    if #(GetEntityCoords(PlayerPedId()) - vector3(sp.x, sp.y, sp.z)) > 25.0 then return end
    if IsAnyVehicleNearPoint(sp.x, sp.y, sp.z, 3.0) then
        QBCore.Functions.Notify('The spawn point is blocked.', 'error') return
    end

    CreateThread(function()
        local hash = GetHashKey(model)
        if not loadModel(hash, 100) then QBCore.Functions.Notify('Could not load that vehicle.', 'error') return end

        local veh = CreateVehicle(hash, sp.x, sp.y, sp.z, sp.w, true, false)
        local plate = 'PD' .. math.random(1000, 9999)
        SetVehicleNumberPlateText(veh, plate)
        SetVehicleFuelLevel(veh, 100.0)
        SetVehicleHasBeenOwnedByPlayer(veh, true)
        SetModelAsNoLongerNeeded(hash)
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
        -- vehicle-keys hook (the "single marked spot" the README mentions)
        if GetResourceState('qb-vehiclekeys') == 'started' then
            TriggerEvent('vehiclekeys:client:SetOwner', plate)
        end
    end)
end)

-- ============================================================
-- BOLO / MDT
-- ============================================================
RegisterNUICallback('fileBolo', function(data, cb)
    TriggerServerEvent('sc_policejob:server:fileBolo', data.subject, data.plate, data.reason)
    cb('ok')
end)

RegisterNUICallback('searchRecords', function(data, cb)
    QBCore.Functions.TriggerCallback('sc_policejob:server:searchRecords', function(results) cb({ results = results }) end, data.query)
end)

RegisterNUICallback('getDutyLog', function(_, cb)   -- was registered twice
    QBCore.Functions.TriggerCallback('sc_policejob:server:getDutyLog', function(data) cb(data or {}) end)
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, obj in ipairs(MyProps) do if DoesEntityExist(obj) then DeleteObject(obj) end end
    SetNuiFocus(false, false)   -- never leave the player with a stuck cursor after a restart
end)
