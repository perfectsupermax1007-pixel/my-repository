SECOND CHANCE RP — STANDALONE POLICE JOB (sc_policejob)
==========================================================

A complete, self-contained QBCore police job. Only needs qb-core
and oxmysql — no sc_dutyrewards, no sc_crimexp, no other resource
from this project required. List-style panels throughout, never a
radial menu.

DO NOT run this alongside sc_policetools — they share command
names (F7/F8) and database tables (pd_citations, pd_arrests,
pd_bolos, pd_impounds) and would conflict. Pick one:
  sc_policejob     -> standalone, everything below, nothing external
  sc_policetools   -> lighter tools+MDT only, built to plug into
                      sc_dutyrewards (service ranks) and sc_crimexp
                      (arrest value scales with suspect's crime level)

SQL
---
All tables are in install.sql — run it against your database before
starting the resource, e.g.:

    mysql -u youruser -p yourdatabase < install.sql

or paste its contents into HeidiSQL / phpMyAdmin. It creates:
pd_citations, pd_arrests, pd_bolos, pd_impounds, pd_dispatch_log,
pd_duty_log, pd_duty_totals.

INSTALL
-------
Drop in resources, run the SQL, `ensure sc_policejob` after qb-core
and oxmysql. Requires the police job/grades to exist in
qb-core/shared/jobs.lua (the shared_jobs.lua from earlier in this
project already includes them — 8 grades, Cadet through Chief).

WHAT'S INCLUDED
-----------------
STATIONS — Mission Row PD and Paleto Bay Sheriff, using the same
verified default coordinates as stock qb-policejob. Walking up to
any station's marked point gives an interact prompt:
  - Duty point: clock on/off (also works via the Toggle Duty
    button in the tools panel — either one works everywhere)
  - Armory point: opens a grade-gated weapon list, tap to issue to
    yourself (ammo auto-included if the matching *_ammo item
    exists in your items table)
  - Vehicle point(s): opens a grade-gated fleet list, tap to spawn
    and get warped into it

FIELD TOOLS (F7) — Cuff/Uncuff, Search Person, Issue Citation (from
a fixed violation list), Make Arrest (requires cuffed target,
built-in holding cell timer, matches active BOLOs as warrant
service), Seize Weapons, Impound Vehicle. Scene props: cone, spike
strip, work light, clear-props.

MDT (F8) — Arrests, Citations, Active BOLOs, File BOLO, Dispatch
Board, Record Search (by name across both arrests and citations),
On Duty roster. Filing requires grade 1+ (Officer I); Cadets are
read-only, enforced server-side.

DISPATCH BOARD
-----------------
Citations, arrests, and BOLOs all ping every on-duty officer, with
zero external dependencies:

1. A toast card slides in top-right for every on-duty officer the
   moment it happens — colored by type (blue for citation/arrest,
   red for a warrant service, amber for a new BOLO) — plus a short
   notification chime. These appear even if the officer doesn't
   have any panel open; they're not gated behind NUI focus.
2. Every alert is also persisted to `pd_dispatch_log` and viewable
   any time from the MDT's "Dispatch Board" tab (last 40 by
   default, Config.DispatchLogLimit) — so an officer who was AFK or
   just came on duty can catch up on what they missed.

Both are on by default and need nothing else installed. If you
LATER add a real dispatch resource (ps-dispatch, cd_dispatch,
qb-dispatch, or your own), every alert also fires a generic hook
you can bind to without losing the built-in board:

    AddEventHandler('sc_policejob:dispatchAlert', function(data)
        -- data = { type = 'citation'|'arrest'|'warrant'|'bolo',
        --          message = 'human-readable line',
        --          coords = vector3, source = officerServerId }
        -- translate into your dispatch resource's alert call here
    end)

This means you can run the built-in board alone, bridge it into a
proper dispatch resource later, or do both at once — the internal
board keeps working either way.

GRADE GATING
--------------
Config.Armory (weapons, keyed by grade) and Config.Garage (vehicles, each with a
minGrade) in config.lua are gated by grade level (0 = Cadet through 7 = Chief, matching
shared_jobs.lua). Vehicle access is cumulative — minGrade means "this grade and up".
Armory access is NOT cumulative (each grade lists its
own full loadout; 'ALL' expands to Config.ArmoryAllWeapons; Config.ArmoryUtilityItems
such as handcuffs go to every grade) so you can shrink access at higher ranks too if
you want (e.g. detectives with fewer patrol weapons) — just edit
the list for that grade directly.

THE HOLDING CELL IS DELIBERATELY LIGHTWEIGHT
-----------------------------------------------
A built-in timer + teleport, not a full jail resource with its own
MLO, visitation, or work-release. Config.HoldingCell is one
vector4 — point it at your station's actual holding area once you
have a real interior for it.

WHAT THIS DOESN'T DO
-----------------------
- No crime-level scaling or duty-reward XP — that's the difference
  from sc_policetools. This version is meant to work completely on
  its own with nothing else installed.

JG-ADVANCEDGARAGES INTEGRATION (VEHICLE RETRIEVAL)
------------------------------------------------------
The Impound Vehicle action now checks for jg-advancedgarages
(GetResourceState) and, if it's running, hands the impound off to
JG'S OWN documented event instead of us guessing at its database:

    TriggerEvent('jg-advancedgarages:client:store-vehicle', garageId, vehicleType)

This is JG's real, documented event (docs.jgscripts.com) for
opening its impound form — the same one their own radial menu/item/
keybind integrations use. We deliberately did NOT write directly to
their `player_vehicles` table (columns like `impound`/`impound_data`
exist, but the exact JSON shape beyond a `reason` field isn't fully
documented, and guessing wrong risks corrupting a real vehicle
record). Letting JG's own code do the write means retrieval through
their existing impound UI just works, correctly, immediately.

SETUP REQUIRED — one line in config.lua:

    Config.JGGarageIntegration.garageId = 'impound'

Change 'impound' to the actual `name` of an impound-type garage in
YOUR jg-advancedgarages config. There's no safe default I can ship
— check your garages table, or run in-game:

    exports["jg-advancedgarages"]:getAllGarages()

...which prints every configured garage's name/type/coords so you
can find the right one.

sc_policejob still writes its own `pd_impounds` row either way, so
the MDT keeps a full audit trail (officer, plate, timestamp)
regardless of which garage script — or none — is installed.

WITHOUT jg-advancedgarages installed, the Impound action falls back
to the original behavior: delete the vehicle on the spot and log it,
same as before this update. No garage script required to use this
resource at all — the integration only activates if it detects one.

Running a different garage script (qs-advancedgarages, jshopgarages,
qb-garages, etc.)? Tell me which one and I'll look up its real
events/exports the same way, rather than guessing.

===========================================================
DISCORD WEBHOOKS
===========================================================
Off by default. To turn one on:

1. In Discord: channel Settings > Integrations > Webhooks > New
   Webhook > Copy Webhook URL. Treat that URL like a password —
   anyone who has it can post to your channel as your bot.
2. In server/config.lua (NOT config.lua — that file is sent to every player), set Config.Webhooks.enabled = true and paste the
   URL into whichever categories you want logged:

    Config.Webhooks.urls.citations = 'https://discord.com/api/webhooks/...'
    Config.Webhooks.urls.arrests   = 'https://discord.com/api/webhooks/...'
    Config.Webhooks.urls.bolos     = 'https://discord.com/api/webhooks/...'
    Config.Webhooks.urls.impounds  = 'https://discord.com/api/webhooks/...'
    Config.Webhooks.urls.duty      = ''  -- leave blank to skip clock-in/out logging

Each category is independent — set only the ones you want, leave
the rest blank. Every send is wrapped in a check for both
Config.Webhooks.enabled and that category having a URL, so nothing
errors or spams if you only fill in one or two.

Warrant-service arrests post to the same `arrests` webhook as a
regular arrest, just with the embed titled "Warrant Served" and
colored differently (matching the dispatch board's own red vs blue
distinction) rather than needing a separate URL.

===========================================================
DUTY TIME LOGGING
===========================================================
Every clock on/off — from the tools panel, the station duty point,
either one — is logged, and a running lifetime total is kept per
officer. Nothing to configure; this is always on.

WHAT'S TRACKED
- pd_duty_log: one row per clock on and per clock off, with the
  off row carrying that session's duration_seconds.
- pd_duty_totals: one row per officer, their all-time total
  duty seconds, incremented every time they clock off.
- Disconnecting while on duty still closes out and logs the
  session properly — it doesn't just vanish uncounted.

WHERE TO SEE IT
- MDT > Duty Log tab: a "Most Active Officers (All-Time)" leader-
  board (top 15 by total time served) and a "Recent Clock In/Out
  Activity" feed (last 50 events, off-duty entries show session
  length). If you're currently on duty, your live session length
  shows at the top of the feed.
- The `duty` Discord webhook (see above), if configured — clock-on
  posts officer + rank, clock-off adds session length, and a
  disconnect-while-on-duty gets its own distinctly-labeled entry
  so you can tell a normal end-of-shift from someone rage-quitting
  mid-pursuit.

EXPORTS FOR THIS SPECIFICALLY
    exports.sc_policejob:GetDutyTotal(citizenid, callback)
        Async — returns that officer's all-time total duty seconds
        via the callback. Useful for a payroll/pension script, an
        activity-gated promotion check, or a profile page.

    exports.sc_policejob:GetCurrentSessionSeconds(serverId)
        Sync — how long (seconds) that player has been on duty
        THIS session, or 0 if they're off duty right now.

===========================================================
EXPORTS — for other resources to integrate with sc_policejob
===========================================================

    exports.sc_policejob:GetOnDutyCount()
        Returns the number of officers currently on duty. Other
        crime scripts (a robbery, a shipment heist, anything that
        should only fire with police actually online) can call this
        instead of writing their own duplicate duty-counting loop.

    exports.sc_policejob:IsCuffed(serverId)
        Returns true/false for whether that player is cuffed.

    exports.sc_policejob:GetActiveBolos()
        Returns a list of { id, subject } for every active BOLO —
        useful if you want to show BOLOs somewhere else, like a
        phone app or a station bulletin-board prop.

    exports.sc_policejob:FileBolo(officerName, officerCid, subject, plate, reason)
        Files a BOLO exactly as if an officer submitted it from the
        MDT — same dispatch board push, same webhook, same
        active-BOLO tracking. Useful for an ANPR camera script, a
        tip line, or an admin panel that needs to raise a BOLO
        without a human at the MDT.

    exports.sc_policejob:SendDispatchAlert(alertType, message, coords, officerSrc)
        Pushes an alert onto the SAME dispatch board sc_policejob's
        own actions use — toast to every on-duty officer, persisted
        to pd_dispatch_log, AND fires the generic sc_policejob:dispatchAlert
        hook. (It does not post to a Discord webhook by itself;
        the built-in actions do that separately.) alertType is typically 'citation' | 'arrest' |
        'warrant' | 'bolo' | 'impound', but any string works —
        unrecognized types just get the default blue toast styling.
        This is the way for an unrelated resource (a robbery script,
        a gunfight detector, anything) to show up on the same board
        officers are already watching, instead of building its own.

    exports.sc_policejob:GetCitizenRecord(citizenid, callback)
        Async (round-trips the database) — returns
        { arrests = n, citations = n } via the callback you pass.
        Useful for an insurance script scaling premiums by record,
        a bail system, or flagging "known offenders" elsewhere:

            exports.sc_policejob:GetCitizenRecord(player.citizenid, function(record)
                print(record.arrests, record.citations)
            end)

===========================================================
CHANGELOG 1.1.0 (optimization + fixes)
===========================================================
UPGRADING: run update_1.1.0.sql once; if you had webhook URLs in config.lua, move them to server/config.lua.

CRASHES / BROKEN FEATURES FIXED
- Armory and fleet never worked: server read Config.ArmoryAccess / VehicleAccess / ArmoryAmmoPerWeapon (not in config);
  client read st.vehicle (config has st.garage) which errored the whole interaction loop.
- Citation/charge pickers were empty (violations/charges were never sent to the NUI) and used 0-based indexes against 1-based tables.
- Picker clicks left NUI focus on with nothing visible (stuck cursor); search results opened with focus off (panel could not be closed).
- Prisoners stayed cuffed through holding and after release.
- Served BOLOs stayed active=1 in the database (reappeared in MDT / after restart).
- Roster showed "undefined" callsigns; handcuffs could not be obtained below the 'ALL' ranks; getDutyLog registered twice.

SECURITY
- Webhook URLs were in a shared script (readable by every client) -> now server-only.
- Armory 'ALL' ranks accepted any item name from the client (spawn any item) -> strict whitelist + must be at an armory.
- Impound let any officer delete any entity by network id and forge the plate -> server validates type/range/occupancy and reads the plate itself.
- Stored XSS in the MDT/toasts via player-controlled names and BOLO text -> all NUI output escaped.
- Server-side enforcement of on-duty, per-action grade, required item (cuff), BOLO write grade; self-targeting blocked; per-action cooldowns;
  all client strings sanitized/length-capped; Discord mentions disabled; LIKE wildcards escaped.

PERFORMANCE
- Interaction loop: police-only, tiered sleep (3000/1000/250/0 ms) instead of a 800ms loop for every player.
- Removed the permanent holding-cell thread, per-second holding ticks, and 20/sec progress-bar messages (NUI animates itself).
- Dispatch toast no longer waits on a DB insert; MDT/duty-log queries run in parallel; explicit column lists; ORDER BY id (PK) instead of created_at.
- GetCitizenRecord is one query; GetDutyTotal/GetCitizenRecord also work synchronously when no callback is given.
- Added indexes; optional retention pruning (server/config.lua); prop cap per officer.

BEHAVIOUR NOTES
- Config.RequireOnDuty (default true) now gates field actions, armory, fleet and BOLO filing. Set false for the old behaviour.
- Duty sessions now close on job change, logout, and disconnect without needing the Player object.
