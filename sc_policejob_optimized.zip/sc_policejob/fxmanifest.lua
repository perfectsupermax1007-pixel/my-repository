fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'sc_policejob'
author 'Second Chance RP'
description 'Standalone QBCore police job — stations, armory, fleet, field tools, MDT. No external dependencies.'
version '1.1.0'

dependencies { 'qb-core', 'oxmysql' }

shared_scripts { 'config.lua' }       -- sent to clients: no secrets in here

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/config.lua',              -- webhook URLs (server-only)
    'server/main.lua',
}

client_scripts { 'client/main.lua' }

ui_page 'html/index.html'
files { 'html/index.html' }
