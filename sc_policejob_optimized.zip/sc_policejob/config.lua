Config = {}

-- ============================================================
-- SECOND CHANCE RP — STANDALONE POLICE JOB (sc_policejob)
--
-- Fully self-contained: duty, stations, armory, vehicle garage,
-- field tools (cuff/search/citation/arrest/seize/impound), and an
-- MDT, all in one resource. No dependency on any other custom
-- resource from this project — only qb-core and oxmysql, which
-- every QBCore server already runs.
--
-- Station and armory coordinates are the verified default
-- locations used by the stock qb-policejob (Mission Row PD +
-- Paleto Bay Sheriff) — not guessed.
-- ============================================================

Config.Job = 'police'
Config.AdminPermission = 'admin'
Config.ToolsKey = 'F7'
Config.MDTKey   = 'F8'

-- ============================================================
-- STATIONS
-- ============================================================
Config.Stations = {
    mrpd = {
        label     = 'Mission Row PD',
        duty      = vector3(441.7989, -982.0529, 30.6896),
        armory    = vector3(462.23, -981.12, 30.68),
        garage    = vector4(454.6, -1017.4, 28.4, 90.654),
        blip      = { sprite = 60, color = 29, scale = 0.8 },
    },
    paleto = {
        label     = 'Paleto Bay Sheriff',
        duty      = vector3(-449.811, 6014.0146, 31.716),
        armory    = vector3(-439.593, 5998.525, 31.716),
        garage    = vector4(-455.39, 6002.02, 31.34, 87.93),
        blip      = { sprite = 60, color = 29, scale = 0.8 },
    },
}

-- ============================================================
-- ARMORY — grade-gated weapon access, given as items (not raw
-- GiveWeapon) so they show up properly in a QBCore inventory.
-- ============================================================
Config.Armory = {
    [0] = { 'weapon_stungun' },
    [1] = { 'weapon_stungun', 'weapon_pistol' },
    [2] = { 'weapon_stungun', 'weapon_pistol', 'weapon_pumpshotgun' },
    [3] = { 'weapon_pistol', 'weapon_pumpshotgun', 'weapon_carbinerifle' },
    [4] = { 'weapon_pistol', 'weapon_carbinerifle', 'weapon_smg' },
    [5] = { 'weapon_pistol', 'weapon_carbinerifle', 'weapon_smg', 'weapon_pumpshotgun' },
    [6] = { 'ALL' },
    [7] = { 'ALL' },
}
Config.ArmoryAllWeapons = {
    'weapon_stungun', 'weapon_pistol', 'weapon_combatpistol', 'weapon_pumpshotgun',
    'weapon_smg', 'weapon_carbinerifle', 'weapon_flashlight',
}
-- Ammo given with any weapon pulled from the armory
Config.ArmoryAmmo = {
    weapon_pistol = 'pistol_ammo', weapon_combatpistol = 'pistol_ammo',
    weapon_smg = 'smg_ammo', weapon_carbinerifle = 'rifle_ammo',
    weapon_pumpshotgun = 'shotgun_ammo',
}

-- ============================================================
-- GARAGE — grade-gated vehicle list. Spawns unlocked and ready to
-- drive; if you run a vehicle-keys resource, wire it in at the
-- single marked spot in client/main.lua.
-- ============================================================
Config.Garage = {
    { model = 'police',    label = 'Police Cruiser',  minGrade = 0 },
    { model = 'police2',   label = 'Police Buffalo',  minGrade = 0 },
    { model = 'police3',   label = 'Police Interceptor', minGrade = 1 },
    { model = 'police4',   label = 'Unmarked Cruiser', minGrade = 2 },
    { model = 'fbi',       label = 'Unmarked SUV',    minGrade = 3 },
    { model = 'riot',      label = 'Riot Van',        minGrade = 4 },
    { model = 'policeb',   label = 'Police Motorcycle', minGrade = 1 },
}

-- ============================================================
-- FIELD ACTIONS (list-style panel — not a radial menu)
-- ============================================================
Config.Actions = {
    {
        id = 'cuff', label = 'Cuff / Uncuff',
        description = 'Restrain or release the nearest player.',
        icon = '⚭', grade = 0, duration = 3000,
        requiredItem = 'handcuffs', consumeItem = false, action = 'cuff',
    },
    {
        id = 'search', label = 'Search Person',
        description = 'Check the nearest player\'s carried items.',
        icon = '⌕', grade = 0, duration = 5000, action = 'search',
    },
    {
        id = 'citation', label = 'Issue Citation',
        description = 'Write a fine for the nearest player.',
        icon = '§', grade = 0, duration = 4000, action = 'citation',
    },
    {
        id = 'arrest', label = 'Make Arrest',
        description = 'Book a cuffed, nearby suspect into holding.',
        icon = '⛓', grade = 0, duration = 6000, action = 'arrest',
    },
    {
        id = 'seize', label = 'Seize Weapons',
        description = 'Confiscate weapons carried by the nearest player.',
        icon = '⊘', grade = 1, duration = 5000, action = 'seize',
    },
    {
        id = 'impound', label = 'Impound Vehicle',
        description = 'Tow the nearest empty vehicle.',
        icon = '▣', grade = 1, duration = 8000, action = 'impound',
    },
}

Config.Utilities = {
    { id = 'toggle_duty', label = 'Toggle Duty',       description = 'Clock on or off shift.',            icon = '◉', grade = 0 },
    { id = 'cone',        label = 'Place Cone',        description = 'Mark a scene perimeter.',           icon = '▲', grade = 0 },
    { id = 'spikestrip',  label = 'Deploy Spike Strip', description = 'Place a spike strip on the road.',  icon = '≡', grade = 0 },
    { id = 'light',       label = 'Place Scene Light', description = 'Illuminate a night scene.',         icon = '☀', grade = 0 },
    { id = 'clear_props', label = 'Clear My Props',    description = 'Remove all scene props you placed.',icon = '✕', grade = 0 },
}
Config.PropModels = {
    cone = 'prop_mp_cone_01', spikestrip = 'p_ld_stinger_s', light = 'prop_worklight_03b',
}

-- ============================================================
-- CITATIONS / ARRESTS
-- ============================================================
Config.Violations = {
    { label = 'Jaywalking', fine = 75 }, { label = 'Reckless Driving', fine = 350 },
    { label = 'Speeding', fine = 200 }, { label = 'Failure to Comply', fine = 250 },
    { label = 'Illegal Parking', fine = 100 }, { label = 'Disorderly Conduct', fine = 300 },
    { label = 'Trespassing', fine = 400 }, { label = 'Weapons Violation', fine = 750 },
}

Config.HoldingCell = vector4(1846.88, 2585.75, 45.67, 90.0) -- Bolingbroke yard; point at your own MLO once you have one
Config.Charges = {
    { label = 'Petty Theft', minutes = 3 }, { label = 'Assault', minutes = 6 },
    { label = 'Drug Possession', minutes = 6 }, { label = 'Grand Theft Auto', minutes = 9 },
    { label = 'Armed Robbery', minutes = 12 }, { label = 'Drug Trafficking', minutes = 15 },
    { label = 'Attempted Murder', minutes = 20 },
}

Config.MDTWriteGrade = 1

Config.MDT = {
    recordsPerPage = 25,
}

-- ============================================================
-- DISPATCH BOARD
-- Citations, arrests, and BOLOs all ping a live board every
-- on-duty officer can see (top-right toast + a persisted MDT tab),
-- with zero external dependencies. Config.DispatchEventName is
-- ALSO fired as a generic hook, so if you later install a real
-- dispatch resource (ps-dispatch, cd_dispatch, qb-dispatch) you
-- can bind to it too without losing the built-in board.
-- ============================================================
Config.DispatchEventName = 'sc_policejob:dispatchAlert'
Config.DispatchToastSeconds = 8
Config.DispatchLogLimit = 40

-- ============================================================
-- JG-ADVANCEDGARAGES INTEGRATION (impound retrieval)
-- jg-advancedgarages already ships its own impound persistence and
-- retrieval UI. Rather than guessing at its database schema and
-- writing to player_vehicles ourselves (real risk of corrupting
-- their impound_data JSON), our Impound action calls JG'S OWN
-- documented event to open its impound form, so JG's tested code
-- does the actual persistence. We still keep our own pd_impounds
-- row for the MDT paper trail (officer, plate, timestamp).
--
-- garageId MUST match the `name` of an actual impound-type garage
-- in YOUR jg-advancedgarages config (check its garages table, or
-- run exports["jg-advancedgarages"]:getAllGarages() to list them).
-- There is no safe default — leaving this wrong means the form
-- opens against the wrong garage.
-- ============================================================
Config.JGGarageIntegration = {
    enabled = true,
    garageId = 'impound',     -- CHANGE THIS to your real impound garage's name
    vehicleType = 'car',      -- 'car' | 'sea' | 'air', per jg-advancedgarages
}

-- ============================================================
-- BEHAVIOUR / LIMITS (added in 1.1.0)
-- ============================================================
Config.RequireOnDuty = true        -- field actions, armory, fleet and BOLO filing require being on duty
Config.ActionCooldownMs = 1000     -- server-side spam guard per action type, per player
Config.ArmoryAmmoPerWeapon = 30    -- ammo item amount issued with a weapon (if the *_ammo item exists)
Config.ArmoryUtilityItems = {      -- issued to every grade, in addition to the weapons above
    { item = 'handcuffs', amount = 5 },
}
Config.ArmoryUseDistance = 10.0    -- server-side: must be this close to a station armory point
Config.MaxProps = 20               -- max scene props (cones/strips/lights) per officer; oldest is removed

-- NOTE: Discord webhook URLs now live in server/config.lua (server-only).
