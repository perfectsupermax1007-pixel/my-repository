-- ============================================================
-- SECOND CHANCE RP — sc_policejob
-- Run this once against your server's database before starting
-- the resource (e.g. via HeidiSQL, phpMyAdmin, or:
--   mysql -u youruser -p yourdatabase < install.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `pd_citations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `officer` VARCHAR(80),
    `officer_cid` VARCHAR(50),
    `citizen_name` VARCHAR(80),
    `citizen_cid` VARCHAR(50),
    `violation` VARCHAR(60),
    `fine` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_cit_cid` (`citizen_cid`)
);

CREATE TABLE IF NOT EXISTS `pd_arrests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `officer` VARCHAR(80),
    `officer_cid` VARCHAR(50),
    `suspect_name` VARCHAR(80),
    `suspect_cid` VARCHAR(50),
    `charges` VARCHAR(60),
    `was_warrant` TINYINT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_arr_cid` (`suspect_cid`)
);

CREATE TABLE IF NOT EXISTS `pd_bolos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `officer` VARCHAR(80),
    `officer_cid` VARCHAR(50),
    `subject` VARCHAR(60),
    `plate` VARCHAR(15),
    `reason` VARCHAR(200),
    `active` TINYINT DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_bolo_active` (`active`)
);

CREATE TABLE IF NOT EXISTS `pd_impounds` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `officer` VARCHAR(80),
    `officer_cid` VARCHAR(50),
    `plate` VARCHAR(15),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Dispatch board: persists every citation/arrest/BOLO alert so the
-- MDT's "Dispatch Board" tab has history beyond the live toast feed.
CREATE TABLE IF NOT EXISTS `pd_dispatch_log` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `type` VARCHAR(20) NOT NULL,
    `message` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_dispatch_created` (`created_at`)
);

-- Duty time tracking: every clock on/off event, plus a running
-- per-officer lifetime total.
CREATE TABLE IF NOT EXISTS `pd_duty_log` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `citizenid` VARCHAR(50) NOT NULL,
    `name` VARCHAR(80) NOT NULL,
    `action` ENUM('on','off') NOT NULL,
    `duration_seconds` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (`citizenid`),
    INDEX `idx_duty_created` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `pd_duty_totals` (
    `citizenid` VARCHAR(50) NOT NULL PRIMARY KEY,
    `name` VARCHAR(80) NOT NULL,
    `total_seconds` BIGINT NOT NULL DEFAULT 0,
    INDEX `idx_totals_seconds` (`total_seconds`)
);
